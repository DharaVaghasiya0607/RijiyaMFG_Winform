﻿namespace AxoneMFGRJ.Transaction
{
    partial class FrmRoughPurchaseView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRoughPurchaseView));
            this.BtnCreateKapan = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.BtnRejectionTransfer = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.MainGrid = new DevExpress.XtraGrid.GridControl();
            this.GrdDet = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn27 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn28 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn29 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn30 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn31 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn32 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn33 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn34 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn35 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn36 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn37 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn38 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn39 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn40 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn41 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn42 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn43 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn44 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn45 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn46 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn47 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn48 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn49 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn50 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn51 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn52 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn53 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn54 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn55 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn56 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn57 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn58 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn59 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn60 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn108 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn134 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn136 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn137 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.chkIsComplete = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn138 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.BtnUpdate = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.panel4 = new AxonContLib.cPanel(this.components);
            this.txtKapan = new AxonContLib.cTextBox(this.components);
            this.cLabel1 = new AxonContLib.cLabel(this.components);
            this.cLabel5 = new AxonContLib.cLabel(this.components);
            this.CmbRoughType = new AxonContLib.cComboBox(this.components);
            this.ChkDisplayAllLot = new AxonContLib.cCheckBox(this.components);
            this.panel8 = new AxonContLib.cPanel(this.components);
            this.BtnSale = new DevExpress.XtraEditors.SimpleButton();
            this.ParcelMix = new DevExpress.XtraEditors.SimpleButton();
            this.BtnParcelSplit = new DevExpress.XtraEditors.SimpleButton();
            this.BtnREPKapanCreate = new DevExpress.XtraEditors.SimpleButton();
            this.BtnPCNKapanCreate = new DevExpress.XtraEditors.SimpleButton();
            this.BtnPrint = new DevExpress.XtraEditors.SimpleButton();
            this.BtnSearch = new DevExpress.XtraEditors.SimpleButton();
            this.BtnAutoFit = new DevExpress.XtraEditors.SimpleButton();
            this.BtnExit = new DevExpress.XtraEditors.SimpleButton();
            this.panel2 = new AxonContLib.cPanel(this.components);
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.lblDefaultLayout = new AxonContLib.cLabel(this.components);
            this.lblSaveLayout = new AxonContLib.cLabel(this.components);
            this.GrpCaption = new DevExpress.XtraEditors.GroupControl();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPageRejection = new DevExpress.XtraTab.XtraTabPage();
            this.lblRejectionDeleteLayout = new AxonContLib.cLabel(this.components);
            this.lblRejectionSaveLayout = new AxonContLib.cLabel(this.components);
            this.MainGridRejection = new DevExpress.XtraGrid.GridControl();
            this.GrdDetRejection = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn83 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn84 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn85 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn86 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txtRejectionName = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridColumn87 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn88 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn89 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn90 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn91 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn92 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn93 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn101 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.BtnRejectionDelete = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn102 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.BtnRejectionUpdate = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemButtonEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.xtraTabPageMixSplit = new DevExpress.XtraTab.XtraTabPage();
            this.lblMixSplitDeleteLayout = new AxonContLib.cLabel(this.components);
            this.lblMixSplitSaveLayout = new AxonContLib.cLabel(this.components);
            this.MainGridMixSplit = new DevExpress.XtraGrid.GridControl();
            this.GrdDetMixSplit = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn61 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn62 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn63 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn64 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn65 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn66 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn67 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn68 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn69 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn70 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn71 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn96 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn97 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.BtnMixSplitDelete = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn98 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPageKapan = new DevExpress.XtraTab.XtraTabPage();
            this.lblKapanDeleteLayout = new AxonContLib.cLabel(this.components);
            this.lblKapanSaveLayout = new AxonContLib.cLabel(this.components);
            this.MainGridKapan = new DevExpress.XtraGrid.GridControl();
            this.GrdDetKapan = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn72 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn73 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn74 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn128 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn75 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn76 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txtManager = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridColumn77 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn78 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn79 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn80 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn81 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn82 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn94 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn95 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn99 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.BtnKapanDelete = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn100 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.BtnKapanUpdate = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn103 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CmbKapanStatus = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.gridColumn104 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn105 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn106 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn107 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn129 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn130 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn131 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn132 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn133 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn135 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnKapanValuation = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn139 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn140 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn141 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn142 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn143 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn144 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPageSale = new DevExpress.XtraTab.XtraTabPage();
            this.lblSaleEntryDeletLayout = new AxonContLib.cLabel(this.components);
            this.lblSaleEntrySaveLayout = new AxonContLib.cLabel(this.components);
            this.MainGridSale = new DevExpress.XtraGrid.GridControl();
            this.GrdDetSale = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn109 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn110 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn111 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn112 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn113 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn114 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn115 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn116 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn127 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn117 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn118 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn119 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn120 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn121 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn122 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn123 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn124 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn125 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn126 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn145 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn146 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnCreateKapan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnRejectionTransfer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsComplete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnUpdate)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrpCaption)).BeginInit();
            this.GrpCaption.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPageRejection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridRejection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDetRejection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRejectionName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnRejectionDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnRejectionUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).BeginInit();
            this.xtraTabPageMixSplit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridMixSplit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDetMixSplit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMixSplitDelete)).BeginInit();
            this.xtraTabPageKapan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridKapan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDetKapan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnKapanDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnKapanUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CmbKapanStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnKapanValuation)).BeginInit();
            this.xtraTabPageSale.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridSale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDetSale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnCreateKapan
            // 
            this.BtnCreateKapan.Appearance.ForeColor = System.Drawing.Color.Green;
            this.BtnCreateKapan.Appearance.Options.UseForeColor = true;
            serializableAppearanceObject1.Font = new System.Drawing.Font("Verdana", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            serializableAppearanceObject1.ForeColor = System.Drawing.Color.Green;
            serializableAppearanceObject1.Options.UseFont = true;
            serializableAppearanceObject1.Options.UseForeColor = true;
            this.BtnCreateKapan.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "Kapan Create", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.BtnCreateKapan.Name = "BtnCreateKapan";
            this.BtnCreateKapan.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.BtnCreateKapan.Click += new System.EventHandler(this.BtnCreateKapan_Click);
            // 
            // BtnRejectionTransfer
            // 
            this.BtnRejectionTransfer.AutoHeight = false;
            serializableAppearanceObject2.Font = new System.Drawing.Font("Verdana", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            serializableAppearanceObject2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            serializableAppearanceObject2.Options.UseFont = true;
            serializableAppearanceObject2.Options.UseForeColor = true;
            this.BtnRejectionTransfer.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "Rejection x\'Fer", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, null, true)});
            this.BtnRejectionTransfer.Name = "BtnRejectionTransfer";
            this.BtnRejectionTransfer.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.BtnRejectionTransfer.Click += new System.EventHandler(this.BtnRejectionTransfer_Click);
            // 
            // MainGrid
            // 
            this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainGrid.Location = new System.Drawing.Point(0, 0);
            this.MainGrid.MainView = this.GrdDet;
            this.MainGrid.Name = "MainGrid";
            this.MainGrid.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.BtnCreateKapan,
            this.BtnRejectionTransfer,
            this.chkIsComplete,
            this.BtnUpdate});
            this.MainGrid.Size = new System.Drawing.Size(1216, 328);
            this.MainGrid.TabIndex = 2;
            this.MainGrid.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.GrdDet});
            // 
            // GrdDet
            // 
            this.GrdDet.Appearance.FocusedCell.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDet.Appearance.FocusedCell.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDet.Appearance.FocusedCell.Font = new System.Drawing.Font("Verdana", 9F);
            this.GrdDet.Appearance.FocusedCell.Options.UseBackColor = true;
            this.GrdDet.Appearance.FocusedCell.Options.UseFont = true;
            this.GrdDet.Appearance.FocusedRow.Font = new System.Drawing.Font("Verdana", 9F);
            this.GrdDet.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GrdDet.Appearance.FocusedRow.Options.UseFont = true;
            this.GrdDet.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GrdDet.Appearance.FooterPanel.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Bold);
            this.GrdDet.Appearance.FooterPanel.Options.UseFont = true;
            this.GrdDet.Appearance.HeaderPanel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold);
            this.GrdDet.Appearance.HeaderPanel.Options.UseFont = true;
            this.GrdDet.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.GrdDet.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GrdDet.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.GrdDet.Appearance.HorzLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDet.Appearance.HorzLine.Options.UseBackColor = true;
            this.GrdDet.Appearance.Row.Font = new System.Drawing.Font("Verdana", 9F);
            this.GrdDet.Appearance.Row.Options.UseFont = true;
            this.GrdDet.Appearance.VertLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDet.Appearance.VertLine.Options.UseBackColor = true;
            this.GrdDet.ColumnPanelRowHeight = 30;
            this.GrdDet.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.bandedGridColumn22,
            this.bandedGridColumn7,
            this.bandedGridColumn1,
            this.bandedGridColumn2,
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn15,
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn18,
            this.gridColumn19,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23,
            this.gridColumn24,
            this.gridColumn25,
            this.gridColumn26,
            this.gridColumn27,
            this.gridColumn28,
            this.gridColumn29,
            this.gridColumn30,
            this.gridColumn31,
            this.gridColumn32,
            this.gridColumn33,
            this.gridColumn34,
            this.gridColumn35,
            this.gridColumn36,
            this.gridColumn37,
            this.gridColumn38,
            this.gridColumn39,
            this.gridColumn40,
            this.gridColumn41,
            this.gridColumn42,
            this.gridColumn43,
            this.gridColumn44,
            this.gridColumn45,
            this.gridColumn46,
            this.gridColumn47,
            this.gridColumn48,
            this.gridColumn49,
            this.gridColumn50,
            this.gridColumn51,
            this.gridColumn52,
            this.gridColumn53,
            this.gridColumn54,
            this.gridColumn55,
            this.gridColumn56,
            this.gridColumn57,
            this.gridColumn58,
            this.gridColumn59,
            this.gridColumn60,
            this.gridColumn108,
            this.gridColumn134,
            this.gridColumn136,
            this.gridColumn137,
            this.gridColumn138});
            this.GrdDet.DetailHeight = 431;
            this.GrdDet.GridControl = this.MainGrid;
            this.GrdDet.Name = "GrdDet";
            this.GrdDet.OptionsCustomization.AllowSort = false;
            this.GrdDet.OptionsFilter.AllowFilterEditor = false;
            this.GrdDet.OptionsPrint.ExpandAllGroups = false;
            this.GrdDet.OptionsView.ColumnAutoWidth = false;
            this.GrdDet.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.GrdDet.OptionsView.ShowAutoFilterRow = true;
            this.GrdDet.OptionsView.ShowFooter = true;
            this.GrdDet.OptionsView.ShowGroupPanel = false;
            this.GrdDet.OptionsView.ShowViewCaption = true;
            this.GrdDet.RowHeight = 25;
            this.GrdDet.ViewCaption = "Purchase Detail";
            this.GrdDet.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.GrdDet_RowCellClick);
            this.GrdDet.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.GrdDet_CustomSummaryCalculate);
            this.GrdDet.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.GrdDet_FocusedRowChanged);
            this.GrdDet.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.GrdDet_CustomColumnDisplayText);
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.AppearanceCell.Font = new System.Drawing.Font("Verdana", 9F);
            this.bandedGridColumn22.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn22.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn22.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn22.Caption = "Rejection";
            this.bandedGridColumn22.ColumnEdit = this.BtnRejectionTransfer;
            this.bandedGridColumn22.FieldName = "REJECTIONTRANSFER";
            this.bandedGridColumn22.MinWidth = 23;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.bandedGridColumn22.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.bandedGridColumn22.Visible = true;
            this.bandedGridColumn22.VisibleIndex = 0;
            this.bandedGridColumn22.Width = 159;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.AppearanceCell.Font = new System.Drawing.Font("Verdana", 9F);
            this.bandedGridColumn7.AppearanceCell.ForeColor = System.Drawing.Color.Green;
            this.bandedGridColumn7.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn7.AppearanceCell.Options.UseForeColor = true;
            this.bandedGridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn7.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn7.Caption = "Create";
            this.bandedGridColumn7.ColumnEdit = this.BtnCreateKapan;
            this.bandedGridColumn7.FieldName = "CREATEKAPAN";
            this.bandedGridColumn7.MinWidth = 23;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.bandedGridColumn7.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.bandedGridColumn7.Visible = true;
            this.bandedGridColumn7.VisibleIndex = 1;
            this.bandedGridColumn7.Width = 149;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn1.Caption = "INVOICE_ID";
            this.bandedGridColumn1.FieldName = "INVOICE_ID";
            this.bandedGridColumn1.MinWidth = 24;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn1.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.bandedGridColumn1.Width = 87;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn2.Caption = "Receive Date";
            this.bandedGridColumn2.FieldName = "RECEIVEDATE";
            this.bandedGridColumn2.MinWidth = 24;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn2.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.VisibleIndex = 11;
            this.bandedGridColumn2.Width = 141;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Font = new System.Drawing.Font("Verdana", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.gridColumn1.AppearanceCell.Options.UseFont = true;
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "System Invoice No";
            this.gridColumn1.FieldName = "SYSTEMINVOICENO";
            this.gridColumn1.MinWidth = 24;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 12;
            this.gridColumn1.Width = 168;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "INVOICEYEAR";
            this.gridColumn2.FieldName = "INVOICEYEAR";
            this.gridColumn2.MinWidth = 24;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn2.Width = 94;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "INVOICEMONTH";
            this.gridColumn3.FieldName = "INVOICEMONTH";
            this.gridColumn3.MinWidth = 24;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn3.Width = 94;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "INVOICENO";
            this.gridColumn4.FieldName = "INVOICENO";
            this.gridColumn4.MinWidth = 24;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn4.Width = 94;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "Manual No";
            this.gridColumn5.FieldName = "MANUALINVOICENO";
            this.gridColumn5.MinWidth = 24;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn5.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count, "MANUALINVOICENO", "{0}")});
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 2;
            this.gridColumn5.Width = 169;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "Party Invoice No";
            this.gridColumn6.FieldName = "PARTYINVOICENO";
            this.gridColumn6.MinWidth = 24;
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 13;
            this.gridColumn6.Width = 169;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "Party Invoice Date";
            this.gridColumn7.FieldName = "PARTYINVOICEDATE";
            this.gridColumn7.MinWidth = 24;
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 14;
            this.gridColumn7.Width = 163;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "PARTY_ID";
            this.gridColumn8.FieldName = "PARTY_ID";
            this.gridColumn8.MinWidth = 24;
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn8.Width = 94;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "Supplier";
            this.gridColumn9.FieldName = "PARTYNAME";
            this.gridColumn9.MinWidth = 24;
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 4;
            this.gridColumn9.Width = 164;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "Terms Days";
            this.gridColumn10.FieldName = "TERMSDAYS";
            this.gridColumn10.MinWidth = 24;
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 41;
            this.gridColumn10.Width = 107;
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.Caption = "Payment Date";
            this.gridColumn11.FieldName = "PAYMENTDATE";
            this.gridColumn11.MinWidth = 24;
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.AllowEdit = false;
            this.gridColumn11.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 42;
            this.gridColumn11.Width = 127;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "Other Company";
            this.gridColumn12.FieldName = "OTHERCOMPANY";
            this.gridColumn12.MinWidth = 24;
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 43;
            this.gridColumn12.Width = 142;
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "Exc Rate";
            this.gridColumn13.DisplayFormat.FormatString = "{0:N3}";
            this.gridColumn13.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn13.FieldName = "EXCRATE";
            this.gridColumn13.MinWidth = 24;
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            this.gridColumn13.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 21;
            this.gridColumn13.Width = 94;
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "Purchase Type";
            this.gridColumn14.FieldName = "PURCHASETYPE";
            this.gridColumn14.MinWidth = 24;
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            this.gridColumn14.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 45;
            this.gridColumn14.Width = 132;
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "Currency Type";
            this.gridColumn15.FieldName = "CURRENCYTYPE";
            this.gridColumn15.MinWidth = 24;
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            this.gridColumn15.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 44;
            this.gridColumn15.Width = 132;
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "Payment Type";
            this.gridColumn16.FieldName = "PAYMENTTYPE";
            this.gridColumn16.MinWidth = 24;
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsColumn.AllowEdit = false;
            this.gridColumn16.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 46;
            this.gridColumn16.Width = 129;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "LOT_ID";
            this.gridColumn17.FieldName = "TERMSPER";
            this.gridColumn17.MinWidth = 24;
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.OptionsColumn.AllowEdit = false;
            this.gridColumn17.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn17.Width = 94;
            // 
            // gridColumn18
            // 
            this.gridColumn18.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn18.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn18.Caption = "Sr.";
            this.gridColumn18.FieldName = "SRNO";
            this.gridColumn18.MinWidth = 24;
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsColumn.AllowEdit = false;
            this.gridColumn18.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 15;
            this.gridColumn18.Width = 94;
            // 
            // gridColumn19
            // 
            this.gridColumn19.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.Caption = "Lot No";
            this.gridColumn19.FieldName = "LOTNO";
            this.gridColumn19.MinWidth = 24;
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsColumn.AllowEdit = false;
            this.gridColumn19.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 3;
            this.gridColumn19.Width = 94;
            // 
            // gridColumn20
            // 
            this.gridColumn20.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn20.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn20.Caption = "Article";
            this.gridColumn20.FieldName = "ARTICLENAME";
            this.gridColumn20.MinWidth = 24;
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.OptionsColumn.AllowEdit = false;
            this.gridColumn20.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 8;
            this.gridColumn20.Width = 94;
            // 
            // gridColumn21
            // 
            this.gridColumn21.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn21.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn21.Caption = "Mines";
            this.gridColumn21.FieldName = "MINESNAME";
            this.gridColumn21.MinWidth = 24;
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.OptionsColumn.AllowEdit = false;
            this.gridColumn21.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 17;
            this.gridColumn21.Width = 94;
            // 
            // gridColumn22
            // 
            this.gridColumn22.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn22.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn22.Caption = "Rough Name";
            this.gridColumn22.FieldName = "ROUGHNAME";
            this.gridColumn22.MinWidth = 24;
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.OptionsColumn.AllowEdit = false;
            this.gridColumn22.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 7;
            this.gridColumn22.Width = 119;
            // 
            // gridColumn23
            // 
            this.gridColumn23.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn23.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn23.Caption = "MSize";
            this.gridColumn23.FieldName = "MSIZENAME";
            this.gridColumn23.MinWidth = 24;
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.OptionsColumn.AllowEdit = false;
            this.gridColumn23.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 18;
            this.gridColumn23.Width = 94;
            // 
            // gridColumn24
            // 
            this.gridColumn24.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn24.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn24.Caption = "Lot Desc.";
            this.gridColumn24.FieldName = "LOTDESCRIPTION";
            this.gridColumn24.MinWidth = 24;
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.OptionsColumn.AllowEdit = false;
            this.gridColumn24.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 19;
            this.gridColumn24.Width = 208;
            // 
            // gridColumn25
            // 
            this.gridColumn25.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn25.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn25.Caption = "Pcs";
            this.gridColumn25.DisplayFormat.FormatString = "{0:f0}";
            this.gridColumn25.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn25.FieldName = "PCS";
            this.gridColumn25.MinWidth = 24;
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.OptionsColumn.AllowEdit = false;
            this.gridColumn25.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn25.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "PCS", "{0:N0}")});
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 20;
            this.gridColumn25.Width = 94;
            // 
            // gridColumn26
            // 
            this.gridColumn26.AppearanceCell.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.gridColumn26.AppearanceCell.Options.UseFont = true;
            this.gridColumn26.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn26.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn26.Caption = "Carat";
            this.gridColumn26.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn26.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn26.FieldName = "CARAT";
            this.gridColumn26.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Right;
            this.gridColumn26.MinWidth = 24;
            this.gridColumn26.Name = "gridColumn26";
            this.gridColumn26.OptionsColumn.AllowEdit = false;
            this.gridColumn26.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn26.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "CARAT", "{0:f2}")});
            this.gridColumn26.Visible = true;
            this.gridColumn26.VisibleIndex = 52;
            this.gridColumn26.Width = 94;
            // 
            // gridColumn27
            // 
            this.gridColumn27.AppearanceCell.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.gridColumn27.AppearanceCell.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.gridColumn27.AppearanceCell.Options.UseFont = true;
            this.gridColumn27.AppearanceCell.Options.UseForeColor = true;
            this.gridColumn27.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn27.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn27.Caption = "Balance";
            this.gridColumn27.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn27.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn27.FieldName = "BALANCECARAT";
            this.gridColumn27.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Right;
            this.gridColumn27.MinWidth = 24;
            this.gridColumn27.Name = "gridColumn27";
            this.gridColumn27.OptionsColumn.AllowEdit = false;
            this.gridColumn27.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn27.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "BALANCECARAT", "{0:f2}")});
            this.gridColumn27.Visible = true;
            this.gridColumn27.VisibleIndex = 53;
            this.gridColumn27.Width = 94;
            // 
            // gridColumn28
            // 
            this.gridColumn28.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn28.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn28.Caption = "Avg Size";
            this.gridColumn28.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn28.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn28.FieldName = "AVGSIZE";
            this.gridColumn28.MinWidth = 24;
            this.gridColumn28.Name = "gridColumn28";
            this.gridColumn28.OptionsColumn.AllowEdit = false;
            this.gridColumn28.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn28.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "{0:N3}", "{0:f2}")});
            this.gridColumn28.Width = 94;
            // 
            // gridColumn29
            // 
            this.gridColumn29.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn29.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn29.Caption = "Rate";
            this.gridColumn29.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn29.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn29.FieldName = "RATE";
            this.gridColumn29.MinWidth = 24;
            this.gridColumn29.Name = "gridColumn29";
            this.gridColumn29.OptionsColumn.AllowEdit = false;
            this.gridColumn29.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn29.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "RATE", "{0:f2}")});
            this.gridColumn29.Visible = true;
            this.gridColumn29.VisibleIndex = 22;
            this.gridColumn29.Width = 94;
            // 
            // gridColumn30
            // 
            this.gridColumn30.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn30.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn30.Caption = "Gross Amount";
            this.gridColumn30.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn30.FieldName = "GROSSAMOUNT";
            this.gridColumn30.MinWidth = 24;
            this.gridColumn30.Name = "gridColumn30";
            this.gridColumn30.OptionsColumn.AllowEdit = false;
            this.gridColumn30.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn30.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "GROSSAMOUNT", "{0:f2}")});
            this.gridColumn30.Visible = true;
            this.gridColumn30.VisibleIndex = 10;
            this.gridColumn30.Width = 129;
            // 
            // gridColumn31
            // 
            this.gridColumn31.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn31.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn31.Caption = "Terms %";
            this.gridColumn31.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn31.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn31.FieldName = "TERMSPER";
            this.gridColumn31.MinWidth = 24;
            this.gridColumn31.Name = "gridColumn31";
            this.gridColumn31.OptionsColumn.AllowEdit = false;
            this.gridColumn31.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn31.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "TERMSPER", "{0:f2}")});
            this.gridColumn31.Visible = true;
            this.gridColumn31.VisibleIndex = 23;
            this.gridColumn31.Width = 94;
            // 
            // gridColumn32
            // 
            this.gridColumn32.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn32.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn32.Caption = "Terms Amt";
            this.gridColumn32.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn32.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn32.FieldName = "TERMSAMOUNT";
            this.gridColumn32.MinWidth = 24;
            this.gridColumn32.Name = "gridColumn32";
            this.gridColumn32.OptionsColumn.AllowEdit = false;
            this.gridColumn32.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn32.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TERMSAMOUNT", "{0:f2}")});
            this.gridColumn32.Visible = true;
            this.gridColumn32.VisibleIndex = 24;
            this.gridColumn32.Width = 103;
            // 
            // gridColumn33
            // 
            this.gridColumn33.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn33.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn33.Caption = "Exp1 %";
            this.gridColumn33.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn33.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn33.FieldName = "EXPPER1";
            this.gridColumn33.MinWidth = 24;
            this.gridColumn33.Name = "gridColumn33";
            this.gridColumn33.OptionsColumn.AllowEdit = false;
            this.gridColumn33.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn33.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "EXPPER1", "{0:f2}")});
            this.gridColumn33.Visible = true;
            this.gridColumn33.VisibleIndex = 25;
            this.gridColumn33.Width = 94;
            // 
            // gridColumn34
            // 
            this.gridColumn34.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn34.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn34.Caption = "Exp1 Amt";
            this.gridColumn34.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn34.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn34.FieldName = "EXPAMOUNT1";
            this.gridColumn34.MinWidth = 24;
            this.gridColumn34.Name = "gridColumn34";
            this.gridColumn34.OptionsColumn.AllowEdit = false;
            this.gridColumn34.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn34.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "EXPAMOUNT1", "{0:f2}")});
            this.gridColumn34.Visible = true;
            this.gridColumn34.VisibleIndex = 26;
            this.gridColumn34.Width = 94;
            // 
            // gridColumn35
            // 
            this.gridColumn35.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn35.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn35.Caption = "Exp2 %";
            this.gridColumn35.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn35.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn35.FieldName = "EXPPER2";
            this.gridColumn35.MinWidth = 24;
            this.gridColumn35.Name = "gridColumn35";
            this.gridColumn35.OptionsColumn.AllowEdit = false;
            this.gridColumn35.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn35.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "EXPPER2", "{0:f2}")});
            this.gridColumn35.Visible = true;
            this.gridColumn35.VisibleIndex = 27;
            this.gridColumn35.Width = 94;
            // 
            // gridColumn36
            // 
            this.gridColumn36.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn36.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn36.Caption = "Exp2 Amt";
            this.gridColumn36.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn36.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn36.FieldName = "EXPAMOUNT2";
            this.gridColumn36.MinWidth = 24;
            this.gridColumn36.Name = "gridColumn36";
            this.gridColumn36.OptionsColumn.AllowEdit = false;
            this.gridColumn36.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn36.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "EXPAMOUNT2", "{0:f2}")});
            this.gridColumn36.Visible = true;
            this.gridColumn36.VisibleIndex = 28;
            this.gridColumn36.Width = 94;
            // 
            // gridColumn37
            // 
            this.gridColumn37.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn37.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn37.Caption = "Exp3 %";
            this.gridColumn37.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn37.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn37.FieldName = "EXPPER3";
            this.gridColumn37.MinWidth = 24;
            this.gridColumn37.Name = "gridColumn37";
            this.gridColumn37.OptionsColumn.AllowEdit = false;
            this.gridColumn37.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn37.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "EXPPER3", "{0:f2}")});
            this.gridColumn37.Visible = true;
            this.gridColumn37.VisibleIndex = 29;
            this.gridColumn37.Width = 94;
            // 
            // gridColumn38
            // 
            this.gridColumn38.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn38.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn38.Caption = "Exp3 Amt";
            this.gridColumn38.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn38.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn38.FieldName = "EXPAMOUNT3";
            this.gridColumn38.MinWidth = 24;
            this.gridColumn38.Name = "gridColumn38";
            this.gridColumn38.OptionsColumn.AllowEdit = false;
            this.gridColumn38.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn38.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "EXPAMOUNT3", "{0:f2}")});
            this.gridColumn38.Visible = true;
            this.gridColumn38.VisibleIndex = 30;
            this.gridColumn38.Width = 94;
            // 
            // gridColumn39
            // 
            this.gridColumn39.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn39.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn39.Caption = "Exp4 %";
            this.gridColumn39.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn39.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn39.FieldName = "EXPPER4";
            this.gridColumn39.MinWidth = 24;
            this.gridColumn39.Name = "gridColumn39";
            this.gridColumn39.OptionsColumn.AllowEdit = false;
            this.gridColumn39.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn39.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "EXPPER4", "{0:f2}")});
            this.gridColumn39.Visible = true;
            this.gridColumn39.VisibleIndex = 31;
            this.gridColumn39.Width = 94;
            // 
            // gridColumn40
            // 
            this.gridColumn40.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn40.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn40.Caption = "Exp4 Amt";
            this.gridColumn40.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn40.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn40.FieldName = "EXPAMOUNT4";
            this.gridColumn40.MinWidth = 24;
            this.gridColumn40.Name = "gridColumn40";
            this.gridColumn40.OptionsColumn.AllowEdit = false;
            this.gridColumn40.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn40.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "EXPAMOUNT4", "{0:f2}")});
            this.gridColumn40.Visible = true;
            this.gridColumn40.VisibleIndex = 32;
            this.gridColumn40.Width = 94;
            // 
            // gridColumn41
            // 
            this.gridColumn41.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn41.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn41.Caption = "Add Less %";
            this.gridColumn41.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn41.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn41.FieldName = "ADDLESSPER";
            this.gridColumn41.MinWidth = 24;
            this.gridColumn41.Name = "gridColumn41";
            this.gridColumn41.OptionsColumn.AllowEdit = false;
            this.gridColumn41.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn41.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ADDLESSPER", "{0:f2}")});
            this.gridColumn41.Visible = true;
            this.gridColumn41.VisibleIndex = 33;
            this.gridColumn41.Width = 111;
            // 
            // gridColumn42
            // 
            this.gridColumn42.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn42.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn42.Caption = "Add Less Amt";
            this.gridColumn42.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn42.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn42.FieldName = "ADDLESSAMOUNT";
            this.gridColumn42.MinWidth = 24;
            this.gridColumn42.Name = "gridColumn42";
            this.gridColumn42.OptionsColumn.AllowEdit = false;
            this.gridColumn42.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn42.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ADDLESSAMOUNT", "{0:f2}")});
            this.gridColumn42.Visible = true;
            this.gridColumn42.VisibleIndex = 34;
            this.gridColumn42.Width = 125;
            // 
            // gridColumn43
            // 
            this.gridColumn43.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn43.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn43.Caption = "Net Amount";
            this.gridColumn43.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn43.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn43.FieldName = "NETAMOUNT";
            this.gridColumn43.MinWidth = 24;
            this.gridColumn43.Name = "gridColumn43";
            this.gridColumn43.OptionsColumn.AllowEdit = false;
            this.gridColumn43.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn43.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "NETAMOUNT", "{0:f2}")});
            this.gridColumn43.Visible = true;
            this.gridColumn43.VisibleIndex = 35;
            this.gridColumn43.Width = 113;
            // 
            // gridColumn44
            // 
            this.gridColumn44.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn44.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn44.Caption = "Brokrage %";
            this.gridColumn44.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn44.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn44.FieldName = "BROKRAGEPER";
            this.gridColumn44.MinWidth = 24;
            this.gridColumn44.Name = "gridColumn44";
            this.gridColumn44.OptionsColumn.AllowEdit = false;
            this.gridColumn44.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn44.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "BROKRAGEPER", "{0:f2}")});
            this.gridColumn44.Visible = true;
            this.gridColumn44.VisibleIndex = 36;
            this.gridColumn44.Width = 113;
            // 
            // gridColumn45
            // 
            this.gridColumn45.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn45.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn45.Caption = "Brokrage Amt";
            this.gridColumn45.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn45.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn45.FieldName = "BROKRAGEAMOUNT";
            this.gridColumn45.MinWidth = 24;
            this.gridColumn45.Name = "gridColumn45";
            this.gridColumn45.OptionsColumn.AllowEdit = false;
            this.gridColumn45.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn45.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "BROKRAGEAMOUNT", "{0:f2}")});
            this.gridColumn45.Visible = true;
            this.gridColumn45.VisibleIndex = 37;
            this.gridColumn45.Width = 127;
            // 
            // gridColumn46
            // 
            this.gridColumn46.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn46.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn46.Caption = "Final Amount";
            this.gridColumn46.DisplayFormat.FormatString = "{0:N3}";
            this.gridColumn46.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn46.FieldName = "FINALAMOUNT";
            this.gridColumn46.MinWidth = 24;
            this.gridColumn46.Name = "gridColumn46";
            this.gridColumn46.OptionsColumn.AllowEdit = false;
            this.gridColumn46.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn46.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "FINALAMOUNT", "{0:N3}")});
            this.gridColumn46.Visible = true;
            this.gridColumn46.VisibleIndex = 38;
            this.gridColumn46.Width = 120;
            // 
            // gridColumn47
            // 
            this.gridColumn47.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn47.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn47.Caption = "BROKER_ID";
            this.gridColumn47.FieldName = "BROKER_ID";
            this.gridColumn47.MinWidth = 24;
            this.gridColumn47.Name = "gridColumn47";
            this.gridColumn47.OptionsColumn.AllowEdit = false;
            this.gridColumn47.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn47.Width = 94;
            // 
            // gridColumn48
            // 
            this.gridColumn48.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn48.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn48.Caption = "Broker Name";
            this.gridColumn48.FieldName = "BROKERNAME";
            this.gridColumn48.MinWidth = 24;
            this.gridColumn48.Name = "gridColumn48";
            this.gridColumn48.OptionsColumn.AllowEdit = false;
            this.gridColumn48.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn48.Visible = true;
            this.gridColumn48.VisibleIndex = 5;
            this.gridColumn48.Width = 125;
            // 
            // gridColumn49
            // 
            this.gridColumn49.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn49.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn49.Caption = "Remark";
            this.gridColumn49.FieldName = "REMARK";
            this.gridColumn49.MinWidth = 24;
            this.gridColumn49.Name = "gridColumn49";
            this.gridColumn49.OptionsColumn.AllowEdit = false;
            this.gridColumn49.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn49.Visible = true;
            this.gridColumn49.VisibleIndex = 39;
            this.gridColumn49.Width = 94;
            // 
            // gridColumn50
            // 
            this.gridColumn50.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn50.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn50.Caption = "Gross + Brok Amt";
            this.gridColumn50.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn50.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn50.FieldName = "GROSSBROKAMOUNT";
            this.gridColumn50.MinWidth = 24;
            this.gridColumn50.Name = "gridColumn50";
            this.gridColumn50.OptionsColumn.AllowEdit = false;
            this.gridColumn50.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn50.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "GROSSBROKAMOUNT", "{0:f2}")});
            this.gridColumn50.Visible = true;
            this.gridColumn50.VisibleIndex = 40;
            this.gridColumn50.Width = 121;
            // 
            // gridColumn51
            // 
            this.gridColumn51.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn51.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn51.Caption = "MAINLOT_ID";
            this.gridColumn51.FieldName = "MAINLOT_ID";
            this.gridColumn51.MinWidth = 24;
            this.gridColumn51.Name = "gridColumn51";
            this.gridColumn51.OptionsColumn.AllowEdit = false;
            this.gridColumn51.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn51.Width = 94;
            // 
            // gridColumn52
            // 
            this.gridColumn52.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn52.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn52.Caption = "MIXSPLITTRN_ID";
            this.gridColumn52.FieldName = "MIXSPLITTRN_ID";
            this.gridColumn52.MinWidth = 24;
            this.gridColumn52.Name = "gridColumn52";
            this.gridColumn52.OptionsColumn.AllowEdit = false;
            this.gridColumn52.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn52.Width = 94;
            // 
            // gridColumn53
            // 
            this.gridColumn53.Caption = "Lot Create Via";
            this.gridColumn53.FieldName = "LOTCREATEVIA";
            this.gridColumn53.MinWidth = 25;
            this.gridColumn53.Name = "gridColumn53";
            this.gridColumn53.OptionsColumn.AllowEdit = false;
            this.gridColumn53.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn53.Visible = true;
            this.gridColumn53.VisibleIndex = 16;
            this.gridColumn53.Width = 133;
            // 
            // gridColumn54
            // 
            this.gridColumn54.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn54.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn54.Caption = "Rate + Dalali";
            this.gridColumn54.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn54.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn54.FieldName = "GROSSBROKRATE";
            this.gridColumn54.MinWidth = 25;
            this.gridColumn54.Name = "gridColumn54";
            this.gridColumn54.OptionsColumn.AllowEdit = false;
            this.gridColumn54.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn54.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom)});
            this.gridColumn54.Visible = true;
            this.gridColumn54.VisibleIndex = 9;
            this.gridColumn54.Width = 123;
            // 
            // gridColumn55
            // 
            this.gridColumn55.Caption = "Entry Date";
            this.gridColumn55.DisplayFormat.FormatString = "dd/MM/yyyy hh:mm:ss tt";
            this.gridColumn55.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn55.FieldName = "ENTRYDATE";
            this.gridColumn55.MinWidth = 25;
            this.gridColumn55.Name = "gridColumn55";
            this.gridColumn55.OptionsColumn.AllowEdit = false;
            this.gridColumn55.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn55.Visible = true;
            this.gridColumn55.VisibleIndex = 47;
            this.gridColumn55.Width = 94;
            // 
            // gridColumn56
            // 
            this.gridColumn56.Caption = "Update Date";
            this.gridColumn56.DisplayFormat.FormatString = "dd/MM/yyyy hh:mm:ss tt";
            this.gridColumn56.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn56.FieldName = "UPDATEDATE";
            this.gridColumn56.MinWidth = 25;
            this.gridColumn56.Name = "gridColumn56";
            this.gridColumn56.OptionsColumn.AllowEdit = false;
            this.gridColumn56.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn56.Visible = true;
            this.gridColumn56.VisibleIndex = 48;
            this.gridColumn56.Width = 94;
            // 
            // gridColumn57
            // 
            this.gridColumn57.AppearanceCell.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Underline);
            this.gridColumn57.AppearanceCell.Options.UseFont = true;
            this.gridColumn57.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn57.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn57.Caption = "Mix Carat";
            this.gridColumn57.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn57.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn57.FieldName = "MIXCARAT";
            this.gridColumn57.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Right;
            this.gridColumn57.MinWidth = 25;
            this.gridColumn57.Name = "gridColumn57";
            this.gridColumn57.OptionsColumn.AllowEdit = false;
            this.gridColumn57.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn57.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "MIXCARAT", "{0:N3}")});
            this.gridColumn57.Visible = true;
            this.gridColumn57.VisibleIndex = 54;
            this.gridColumn57.Width = 94;
            // 
            // gridColumn58
            // 
            this.gridColumn58.AppearanceCell.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Underline);
            this.gridColumn58.AppearanceCell.Options.UseFont = true;
            this.gridColumn58.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn58.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn58.Caption = "Split Carat";
            this.gridColumn58.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn58.FieldName = "SPLITCARAT";
            this.gridColumn58.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Right;
            this.gridColumn58.MinWidth = 25;
            this.gridColumn58.Name = "gridColumn58";
            this.gridColumn58.OptionsColumn.AllowEdit = false;
            this.gridColumn58.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn58.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SPLITCARAT", "{0:N3}")});
            this.gridColumn58.Visible = true;
            this.gridColumn58.VisibleIndex = 55;
            this.gridColumn58.Width = 94;
            // 
            // gridColumn59
            // 
            this.gridColumn59.AppearanceCell.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Underline);
            this.gridColumn59.AppearanceCell.Options.UseFont = true;
            this.gridColumn59.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn59.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn59.Caption = "Kapan Carat";
            this.gridColumn59.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn59.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn59.FieldName = "KAPANCARAT";
            this.gridColumn59.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Right;
            this.gridColumn59.MinWidth = 25;
            this.gridColumn59.Name = "gridColumn59";
            this.gridColumn59.OptionsColumn.AllowEdit = false;
            this.gridColumn59.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn59.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "KAPANCARAT", "{0:N3}")});
            this.gridColumn59.Visible = true;
            this.gridColumn59.VisibleIndex = 56;
            this.gridColumn59.Width = 94;
            // 
            // gridColumn60
            // 
            this.gridColumn60.AppearanceCell.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Underline);
            this.gridColumn60.AppearanceCell.Options.UseFont = true;
            this.gridColumn60.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn60.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn60.Caption = "Rejection Carat";
            this.gridColumn60.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn60.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn60.FieldName = "REJECTIONCARAT";
            this.gridColumn60.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Right;
            this.gridColumn60.MinWidth = 25;
            this.gridColumn60.Name = "gridColumn60";
            this.gridColumn60.OptionsColumn.AllowEdit = false;
            this.gridColumn60.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn60.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "REJECTIONCARAT", "{0:N3}")});
            this.gridColumn60.Visible = true;
            this.gridColumn60.VisibleIndex = 57;
            this.gridColumn60.Width = 94;
            // 
            // gridColumn108
            // 
            this.gridColumn108.AppearanceCell.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Underline);
            this.gridColumn108.AppearanceCell.Options.UseFont = true;
            this.gridColumn108.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn108.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn108.Caption = "Sale Carat";
            this.gridColumn108.DisplayFormat.FormatString = "{0:f2}";
            this.gridColumn108.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn108.FieldName = "SALECARAT";
            this.gridColumn108.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Right;
            this.gridColumn108.Name = "gridColumn108";
            this.gridColumn108.OptionsColumn.AllowEdit = false;
            this.gridColumn108.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn108.Visible = true;
            this.gridColumn108.VisibleIndex = 58;
            // 
            // gridColumn134
            // 
            this.gridColumn134.Caption = "RoughType";
            this.gridColumn134.FieldName = "ROUGHTYPE";
            this.gridColumn134.Name = "gridColumn134";
            this.gridColumn134.OptionsColumn.AllowEdit = false;
            this.gridColumn134.Visible = true;
            this.gridColumn134.VisibleIndex = 6;
            this.gridColumn134.Width = 129;
            // 
            // gridColumn136
            // 
            this.gridColumn136.Caption = "Complete Date";
            this.gridColumn136.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn136.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn136.FieldName = "COMPLETEDATE";
            this.gridColumn136.Name = "gridColumn136";
            this.gridColumn136.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn136.Visible = true;
            this.gridColumn136.VisibleIndex = 49;
            // 
            // gridColumn137
            // 
            this.gridColumn137.Caption = "Is Complete";
            this.gridColumn137.ColumnEdit = this.chkIsComplete;
            this.gridColumn137.FieldName = "ISCOMPLETE";
            this.gridColumn137.Name = "gridColumn137";
            this.gridColumn137.Visible = true;
            this.gridColumn137.VisibleIndex = 50;
            // 
            // chkIsComplete
            // 
            this.chkIsComplete.Caption = "Check";
            this.chkIsComplete.Name = "chkIsComplete";
            this.chkIsComplete.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Inactive;
            // 
            // gridColumn138
            // 
            this.gridColumn138.Caption = "Update";
            this.gridColumn138.ColumnEdit = this.BtnUpdate;
            this.gridColumn138.Name = "gridColumn138";
            this.gridColumn138.Visible = true;
            this.gridColumn138.VisibleIndex = 51;
            // 
            // BtnUpdate
            // 
            this.BtnUpdate.Appearance.ForeColor = System.Drawing.Color.Green;
            this.BtnUpdate.Appearance.Options.UseForeColor = true;
            this.BtnUpdate.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.BtnUpdate.Name = "BtnUpdate";
            this.BtnUpdate.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtKapan);
            this.panel4.Controls.Add(this.cLabel1);
            this.panel4.Controls.Add(this.cLabel5);
            this.panel4.Controls.Add(this.CmbRoughType);
            this.panel4.Controls.Add(this.ChkDisplayAllLot);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.BtnPrint);
            this.panel4.Controls.Add(this.BtnSearch);
            this.panel4.Controls.Add(this.BtnAutoFit);
            this.panel4.Controls.Add(this.BtnExit);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1216, 78);
            this.panel4.TabIndex = 0;
            // 
            // txtKapan
            // 
            this.txtKapan.ActivationColor = true;
            this.txtKapan.ActivationColorCode = System.Drawing.Color.Empty;
            this.txtKapan.AllowTabKeyOnEnter = false;
            this.txtKapan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtKapan.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKapan.Format = "";
            this.txtKapan.IsComplusory = false;
            this.txtKapan.Location = new System.Drawing.Point(60, 9);
            this.txtKapan.Name = "txtKapan";
            this.txtKapan.SelectAllTextOnFocus = true;
            this.txtKapan.Size = new System.Drawing.Size(157, 22);
            this.txtKapan.TabIndex = 213;
            this.txtKapan.ToolTips = "";
            this.txtKapan.WaterMarkText = null;
            this.txtKapan.Validated += new System.EventHandler(this.txtKapan_Validated);
            // 
            // cLabel1
            // 
            this.cLabel1.AutoSize = true;
            this.cLabel1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cLabel1.ForeColor = System.Drawing.Color.Black;
            this.cLabel1.Location = new System.Drawing.Point(12, 13);
            this.cLabel1.Name = "cLabel1";
            this.cLabel1.Size = new System.Drawing.Size(48, 14);
            this.cLabel1.TabIndex = 212;
            this.cLabel1.Text = "&Kapan";
            this.cLabel1.ToolTips = "";
            // 
            // cLabel5
            // 
            this.cLabel5.AutoSize = true;
            this.cLabel5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cLabel5.ForeColor = System.Drawing.Color.Black;
            this.cLabel5.Location = new System.Drawing.Point(225, 13);
            this.cLabel5.Name = "cLabel5";
            this.cLabel5.Size = new System.Drawing.Size(84, 14);
            this.cLabel5.TabIndex = 212;
            this.cLabel5.Text = "Rough Type";
            this.cLabel5.ToolTips = "";
            // 
            // CmbRoughType
            // 
            this.CmbRoughType.AllowTabKeyOnEnter = true;
            this.CmbRoughType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbRoughType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmbRoughType.ForeColor = System.Drawing.Color.Black;
            this.CmbRoughType.FormattingEnabled = true;
            this.CmbRoughType.Items.AddRange(new object[] {
            "NATURAL",
            "CVD",
            "HPHT",
            "ALL"});
            this.CmbRoughType.Location = new System.Drawing.Point(315, 9);
            this.CmbRoughType.Name = "CmbRoughType";
            this.CmbRoughType.Size = new System.Drawing.Size(118, 22);
            this.CmbRoughType.TabIndex = 164;
            this.CmbRoughType.ToolTips = "";
            // 
            // ChkDisplayAllLot
            // 
            this.ChkDisplayAllLot.AllowTabKeyOnEnter = false;
            this.ChkDisplayAllLot.AutoSize = true;
            this.ChkDisplayAllLot.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChkDisplayAllLot.Location = new System.Drawing.Point(438, 11);
            this.ChkDisplayAllLot.Name = "ChkDisplayAllLot";
            this.ChkDisplayAllLot.Size = new System.Drawing.Size(232, 18);
            this.ChkDisplayAllLot.TabIndex = 163;
            this.ChkDisplayAllLot.Text = "Display All Lots With 0 Balance";
            this.ChkDisplayAllLot.ToolTips = "";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.BtnSale);
            this.panel8.Controls.Add(this.ParcelMix);
            this.panel8.Controls.Add(this.BtnParcelSplit);
            this.panel8.Controls.Add(this.BtnREPKapanCreate);
            this.panel8.Controls.Add(this.BtnPCNKapanCreate);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel8.Location = new System.Drawing.Point(597, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(619, 78);
            this.panel8.TabIndex = 162;
            // 
            // BtnSale
            // 
            this.BtnSale.Appearance.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.BtnSale.Appearance.ForeColor = System.Drawing.Color.Black;
            this.BtnSale.Appearance.Options.UseFont = true;
            this.BtnSale.Appearance.Options.UseForeColor = true;
            this.BtnSale.Location = new System.Drawing.Point(222, 14);
            this.BtnSale.Name = "BtnSale";
            this.BtnSale.Size = new System.Drawing.Size(89, 34);
            this.BtnSale.TabIndex = 155;
            this.BtnSale.TabStop = false;
            this.BtnSale.Text = "Sale";
            this.BtnSale.Click += new System.EventHandler(this.BtnSale_Click);
            // 
            // ParcelMix
            // 
            this.ParcelMix.Appearance.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.ParcelMix.Appearance.ForeColor = System.Drawing.Color.Black;
            this.ParcelMix.Appearance.Options.UseFont = true;
            this.ParcelMix.Appearance.Options.UseForeColor = true;
            this.ParcelMix.Location = new System.Drawing.Point(111, 14);
            this.ParcelMix.Name = "ParcelMix";
            this.ParcelMix.Size = new System.Drawing.Size(105, 34);
            this.ParcelMix.TabIndex = 155;
            this.ParcelMix.TabStop = false;
            this.ParcelMix.Text = "Parcel Mix";
            this.ParcelMix.Click += new System.EventHandler(this.ParcelMix_Click);
            // 
            // BtnParcelSplit
            // 
            this.BtnParcelSplit.Appearance.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.BtnParcelSplit.Appearance.ForeColor = System.Drawing.Color.Black;
            this.BtnParcelSplit.Appearance.Options.UseFont = true;
            this.BtnParcelSplit.Appearance.Options.UseForeColor = true;
            this.BtnParcelSplit.Location = new System.Drawing.Point(9, 14);
            this.BtnParcelSplit.Name = "BtnParcelSplit";
            this.BtnParcelSplit.Size = new System.Drawing.Size(98, 34);
            this.BtnParcelSplit.TabIndex = 158;
            this.BtnParcelSplit.TabStop = false;
            this.BtnParcelSplit.Text = "Parcel Split";
            this.BtnParcelSplit.Click += new System.EventHandler(this.BtnParcelSplit_Click);
            // 
            // BtnREPKapanCreate
            // 
            this.BtnREPKapanCreate.Appearance.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.BtnREPKapanCreate.Appearance.ForeColor = System.Drawing.Color.Black;
            this.BtnREPKapanCreate.Appearance.Options.UseFont = true;
            this.BtnREPKapanCreate.Appearance.Options.UseForeColor = true;
            this.BtnREPKapanCreate.Image = global::AxoneMFGRJ.Properties.Resources.btnsave;
            this.BtnREPKapanCreate.Location = new System.Drawing.Point(316, 14);
            this.BtnREPKapanCreate.Name = "BtnREPKapanCreate";
            this.BtnREPKapanCreate.Size = new System.Drawing.Size(145, 34);
            this.BtnREPKapanCreate.TabIndex = 154;
            this.BtnREPKapanCreate.TabStop = false;
            this.BtnREPKapanCreate.Text = "REP Kapan Create";
            this.BtnREPKapanCreate.Click += new System.EventHandler(this.BtnREPKapanCreate_Click);
            // 
            // BtnPCNKapanCreate
            // 
            this.BtnPCNKapanCreate.Appearance.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.BtnPCNKapanCreate.Appearance.ForeColor = System.Drawing.Color.Black;
            this.BtnPCNKapanCreate.Appearance.Options.UseFont = true;
            this.BtnPCNKapanCreate.Appearance.Options.UseForeColor = true;
            this.BtnPCNKapanCreate.Image = global::AxoneMFGRJ.Properties.Resources.btnsave;
            this.BtnPCNKapanCreate.Location = new System.Drawing.Point(467, 14);
            this.BtnPCNKapanCreate.Name = "BtnPCNKapanCreate";
            this.BtnPCNKapanCreate.Size = new System.Drawing.Size(145, 34);
            this.BtnPCNKapanCreate.TabIndex = 153;
            this.BtnPCNKapanCreate.TabStop = false;
            this.BtnPCNKapanCreate.Text = "PCN Kapan Create";
            this.BtnPCNKapanCreate.Click += new System.EventHandler(this.BtnPCNKapanCreate_Click);
            // 
            // BtnPrint
            // 
            this.BtnPrint.Appearance.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.BtnPrint.Appearance.ForeColor = System.Drawing.Color.Black;
            this.BtnPrint.Appearance.Options.UseFont = true;
            this.BtnPrint.Appearance.Options.UseForeColor = true;
            this.BtnPrint.Image = global::AxoneMFGRJ.Properties.Resources.btnexcelexport;
            this.BtnPrint.Location = new System.Drawing.Point(232, 37);
            this.BtnPrint.Name = "BtnPrint";
            this.BtnPrint.Size = new System.Drawing.Size(80, 35);
            this.BtnPrint.TabIndex = 152;
            this.BtnPrint.TabStop = false;
            this.BtnPrint.Text = "Export";
            this.BtnPrint.Click += new System.EventHandler(this.BtnExport_Click);
            // 
            // BtnSearch
            // 
            this.BtnSearch.Appearance.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.BtnSearch.Appearance.ForeColor = System.Drawing.Color.Black;
            this.BtnSearch.Appearance.Options.UseFont = true;
            this.BtnSearch.Appearance.Options.UseForeColor = true;
            this.BtnSearch.Image = ((System.Drawing.Image)(resources.GetObject("BtnSearch.Image")));
            this.BtnSearch.Location = new System.Drawing.Point(60, 37);
            this.BtnSearch.Name = "BtnSearch";
            this.BtnSearch.Size = new System.Drawing.Size(80, 35);
            this.BtnSearch.TabIndex = 149;
            this.BtnSearch.Text = "Search";
            this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // BtnAutoFit
            // 
            this.BtnAutoFit.Appearance.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.BtnAutoFit.Appearance.ForeColor = System.Drawing.Color.Black;
            this.BtnAutoFit.Appearance.Options.UseFont = true;
            this.BtnAutoFit.Appearance.Options.UseForeColor = true;
            this.BtnAutoFit.Image = global::AxoneMFGRJ.Properties.Resources.btnbestfit;
            this.BtnAutoFit.Location = new System.Drawing.Point(146, 37);
            this.BtnAutoFit.Name = "BtnAutoFit";
            this.BtnAutoFit.Size = new System.Drawing.Size(80, 35);
            this.BtnAutoFit.TabIndex = 150;
            this.BtnAutoFit.TabStop = false;
            this.BtnAutoFit.Text = "Best Fit";
            this.BtnAutoFit.Click += new System.EventHandler(this.BtnAutoFit_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.Appearance.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.BtnExit.Appearance.ForeColor = System.Drawing.Color.Black;
            this.BtnExit.Appearance.Options.UseFont = true;
            this.BtnExit.Appearance.Options.UseForeColor = true;
            this.BtnExit.Image = global::AxoneMFGRJ.Properties.Resources.btnexit;
            this.BtnExit.Location = new System.Drawing.Point(318, 37);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(80, 35);
            this.BtnExit.TabIndex = 151;
            this.BtnExit.TabStop = false;
            this.BtnExit.Text = "E&xit";
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.splitContainerControl1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 78);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1216, 561);
            this.panel2.TabIndex = 19;
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.Horizontal = false;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.lblDefaultLayout);
            this.splitContainerControl1.Panel1.Controls.Add(this.lblSaveLayout);
            this.splitContainerControl1.Panel1.Controls.Add(this.MainGrid);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.GrpCaption);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1216, 561);
            this.splitContainerControl1.SplitterPosition = 328;
            this.splitContainerControl1.TabIndex = 3;
            // 
            // lblDefaultLayout
            // 
            this.lblDefaultLayout.AutoSize = true;
            this.lblDefaultLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblDefaultLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDefaultLayout.ForeColor = System.Drawing.Color.Navy;
            this.lblDefaultLayout.Location = new System.Drawing.Point(102, 5);
            this.lblDefaultLayout.Name = "lblDefaultLayout";
            this.lblDefaultLayout.Size = new System.Drawing.Size(97, 13);
            this.lblDefaultLayout.TabIndex = 151;
            this.lblDefaultLayout.Text = "Delete Layout";
            this.lblDefaultLayout.ToolTips = "";
            this.lblDefaultLayout.Click += new System.EventHandler(this.lblDefaultLayout_Click);
            // 
            // lblSaveLayout
            // 
            this.lblSaveLayout.AutoSize = true;
            this.lblSaveLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSaveLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaveLayout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblSaveLayout.Location = new System.Drawing.Point(9, 5);
            this.lblSaveLayout.Name = "lblSaveLayout";
            this.lblSaveLayout.Size = new System.Drawing.Size(87, 13);
            this.lblSaveLayout.TabIndex = 152;
            this.lblSaveLayout.Text = "Save Layout";
            this.lblSaveLayout.ToolTips = "";
            this.lblSaveLayout.Click += new System.EventHandler(this.lblSaveLayout_Click);
            // 
            // GrpCaption
            // 
            this.GrpCaption.AppearanceCaption.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold);
            this.GrpCaption.AppearanceCaption.Options.UseFont = true;
            this.GrpCaption.AppearanceCaption.Options.UseTextOptions = true;
            this.GrpCaption.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GrpCaption.Controls.Add(this.xtraTabControl1);
            this.GrpCaption.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GrpCaption.Location = new System.Drawing.Point(0, 0);
            this.GrpCaption.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GrpCaption.Name = "GrpCaption";
            this.GrpCaption.Size = new System.Drawing.Size(1216, 228);
            this.GrpCaption.TabIndex = 1;
            this.GrpCaption.Text = "groupControl1";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.AppearancePage.Header.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold);
            this.xtraTabControl1.AppearancePage.Header.Options.UseFont = true;
            this.xtraTabControl1.AppearancePage.HeaderActive.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold);
            this.xtraTabControl1.AppearancePage.HeaderActive.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseFont = true;
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseForeColor = true;
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(2, 21);
            this.xtraTabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPageRejection;
            this.xtraTabControl1.Size = new System.Drawing.Size(1212, 205);
            this.xtraTabControl1.TabIndex = 0;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPageMixSplit,
            this.xtraTabPageKapan,
            this.xtraTabPageRejection,
            this.xtraTabPageSale});
            // 
            // xtraTabPageRejection
            // 
            this.xtraTabPageRejection.Controls.Add(this.lblRejectionDeleteLayout);
            this.xtraTabPageRejection.Controls.Add(this.lblRejectionSaveLayout);
            this.xtraTabPageRejection.Controls.Add(this.MainGridRejection);
            this.xtraTabPageRejection.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xtraTabPageRejection.Name = "xtraTabPageRejection";
            this.xtraTabPageRejection.Size = new System.Drawing.Size(1206, 178);
            this.xtraTabPageRejection.Text = "     REJECTION     ";
            // 
            // lblRejectionDeleteLayout
            // 
            this.lblRejectionDeleteLayout.AutoSize = true;
            this.lblRejectionDeleteLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblRejectionDeleteLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRejectionDeleteLayout.ForeColor = System.Drawing.Color.Navy;
            this.lblRejectionDeleteLayout.Location = new System.Drawing.Point(102, 4);
            this.lblRejectionDeleteLayout.Name = "lblRejectionDeleteLayout";
            this.lblRejectionDeleteLayout.Size = new System.Drawing.Size(97, 13);
            this.lblRejectionDeleteLayout.TabIndex = 153;
            this.lblRejectionDeleteLayout.Text = "Delete Layout";
            this.lblRejectionDeleteLayout.ToolTips = "";
            this.lblRejectionDeleteLayout.Click += new System.EventHandler(this.lblRejectionDeleteLayout_Click);
            // 
            // lblRejectionSaveLayout
            // 
            this.lblRejectionSaveLayout.AutoSize = true;
            this.lblRejectionSaveLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblRejectionSaveLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRejectionSaveLayout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblRejectionSaveLayout.Location = new System.Drawing.Point(9, 4);
            this.lblRejectionSaveLayout.Name = "lblRejectionSaveLayout";
            this.lblRejectionSaveLayout.Size = new System.Drawing.Size(87, 13);
            this.lblRejectionSaveLayout.TabIndex = 154;
            this.lblRejectionSaveLayout.Text = "Save Layout";
            this.lblRejectionSaveLayout.ToolTips = "";
            this.lblRejectionSaveLayout.Click += new System.EventHandler(this.lblRejectionSaveLayout_Click);
            // 
            // MainGridRejection
            // 
            this.MainGridRejection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainGridRejection.Location = new System.Drawing.Point(0, 0);
            this.MainGridRejection.MainView = this.GrdDetRejection;
            this.MainGridRejection.Name = "MainGridRejection";
            this.MainGridRejection.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.BtnRejectionDelete,
            this.BtnRejectionUpdate,
            this.txtRejectionName,
            this.repositoryItemButtonEdit3});
            this.MainGridRejection.Size = new System.Drawing.Size(1206, 178);
            this.MainGridRejection.TabIndex = 5;
            this.MainGridRejection.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.GrdDetRejection});
            // 
            // GrdDetRejection
            // 
            this.GrdDetRejection.Appearance.FocusedCell.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDetRejection.Appearance.FocusedCell.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDetRejection.Appearance.FocusedCell.Font = new System.Drawing.Font("Verdana", 9F);
            this.GrdDetRejection.Appearance.FocusedCell.Options.UseBackColor = true;
            this.GrdDetRejection.Appearance.FocusedCell.Options.UseFont = true;
            this.GrdDetRejection.Appearance.FocusedRow.Font = new System.Drawing.Font("Verdana", 8F);
            this.GrdDetRejection.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GrdDetRejection.Appearance.FocusedRow.Options.UseFont = true;
            this.GrdDetRejection.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GrdDetRejection.Appearance.FooterPanel.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Bold);
            this.GrdDetRejection.Appearance.FooterPanel.Options.UseFont = true;
            this.GrdDetRejection.Appearance.HeaderPanel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold);
            this.GrdDetRejection.Appearance.HeaderPanel.Options.UseFont = true;
            this.GrdDetRejection.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.GrdDetRejection.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GrdDetRejection.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.GrdDetRejection.Appearance.HorzLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDetRejection.Appearance.HorzLine.Options.UseBackColor = true;
            this.GrdDetRejection.Appearance.Row.Font = new System.Drawing.Font("Verdana", 8F);
            this.GrdDetRejection.Appearance.Row.Options.UseFont = true;
            this.GrdDetRejection.Appearance.VertLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDetRejection.Appearance.VertLine.Options.UseBackColor = true;
            this.GrdDetRejection.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn83,
            this.gridColumn84,
            this.gridColumn85,
            this.gridColumn86,
            this.gridColumn87,
            this.gridColumn88,
            this.gridColumn89,
            this.gridColumn90,
            this.gridColumn91,
            this.gridColumn92,
            this.gridColumn93,
            this.gridColumn101,
            this.gridColumn102});
            this.GrdDetRejection.DetailHeight = 431;
            this.GrdDetRejection.GridControl = this.MainGridRejection;
            this.GrdDetRejection.Name = "GrdDetRejection";
            this.GrdDetRejection.OptionsCustomization.AllowSort = false;
            this.GrdDetRejection.OptionsFilter.AllowFilterEditor = false;
            this.GrdDetRejection.OptionsPrint.ExpandAllGroups = false;
            this.GrdDetRejection.OptionsView.ColumnAutoWidth = false;
            this.GrdDetRejection.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.GrdDetRejection.OptionsView.ShowFooter = true;
            this.GrdDetRejection.OptionsView.ShowGroupPanel = false;
            this.GrdDetRejection.OptionsView.ShowViewCaption = true;
            this.GrdDetRejection.ViewCaption = "Rejection Detail";
            this.GrdDetRejection.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.GrdDetRejection_CustomSummaryCalculate);
            this.GrdDetRejection.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.GrdDetRejection_CellValueChanged);
            // 
            // gridColumn83
            // 
            this.gridColumn83.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn83.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn83.Caption = "Lot No";
            this.gridColumn83.FieldName = "LOTNO";
            this.gridColumn83.MinWidth = 25;
            this.gridColumn83.Name = "gridColumn83";
            this.gridColumn83.OptionsColumn.AllowEdit = false;
            this.gridColumn83.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn83.Visible = true;
            this.gridColumn83.VisibleIndex = 2;
            this.gridColumn83.Width = 94;
            // 
            // gridColumn84
            // 
            this.gridColumn84.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn84.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn84.Caption = "Rejection TRN ID";
            this.gridColumn84.FieldName = "REJECTIONTRN_ID";
            this.gridColumn84.MinWidth = 25;
            this.gridColumn84.Name = "gridColumn84";
            this.gridColumn84.OptionsColumn.AllowEdit = false;
            this.gridColumn84.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn84.Width = 94;
            // 
            // gridColumn85
            // 
            this.gridColumn85.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn85.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn85.Caption = "REJECTION_ID";
            this.gridColumn85.FieldName = "REJECTION_ID";
            this.gridColumn85.MinWidth = 25;
            this.gridColumn85.Name = "gridColumn85";
            this.gridColumn85.OptionsColumn.AllowEdit = false;
            this.gridColumn85.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn85.Width = 94;
            // 
            // gridColumn86
            // 
            this.gridColumn86.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn86.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn86.Caption = "Rejection";
            this.gridColumn86.ColumnEdit = this.txtRejectionName;
            this.gridColumn86.FieldName = "REJECTIONNAME";
            this.gridColumn86.MinWidth = 25;
            this.gridColumn86.Name = "gridColumn86";
            this.gridColumn86.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn86.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count)});
            this.gridColumn86.Visible = true;
            this.gridColumn86.VisibleIndex = 3;
            this.gridColumn86.Width = 167;
            // 
            // txtRejectionName
            // 
            this.txtRejectionName.AutoHeight = false;
            this.txtRejectionName.Name = "txtRejectionName";
            this.txtRejectionName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRejectionName_KeyPress);
            // 
            // gridColumn87
            // 
            this.gridColumn87.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn87.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn87.Caption = "Rejection Date";
            this.gridColumn87.FieldName = "REJECTIONDATE";
            this.gridColumn87.MinWidth = 25;
            this.gridColumn87.Name = "gridColumn87";
            this.gridColumn87.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn87.Visible = true;
            this.gridColumn87.VisibleIndex = 4;
            this.gridColumn87.Width = 147;
            // 
            // gridColumn88
            // 
            this.gridColumn88.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn88.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn88.Caption = "Pcs";
            this.gridColumn88.FieldName = "PCS";
            this.gridColumn88.MinWidth = 25;
            this.gridColumn88.Name = "gridColumn88";
            this.gridColumn88.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn88.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "PCS", "{0:0.##}")});
            this.gridColumn88.Visible = true;
            this.gridColumn88.VisibleIndex = 5;
            this.gridColumn88.Width = 94;
            // 
            // gridColumn89
            // 
            this.gridColumn89.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn89.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn89.Caption = "Carat";
            this.gridColumn89.FieldName = "CARAT";
            this.gridColumn89.MinWidth = 25;
            this.gridColumn89.Name = "gridColumn89";
            this.gridColumn89.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn89.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "CARAT", "{0:0.##}")});
            this.gridColumn89.Visible = true;
            this.gridColumn89.VisibleIndex = 6;
            this.gridColumn89.Width = 94;
            // 
            // gridColumn90
            // 
            this.gridColumn90.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn90.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn90.Caption = "Rate";
            this.gridColumn90.FieldName = "RATE";
            this.gridColumn90.MinWidth = 25;
            this.gridColumn90.Name = "gridColumn90";
            this.gridColumn90.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn90.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom)});
            this.gridColumn90.Visible = true;
            this.gridColumn90.VisibleIndex = 7;
            this.gridColumn90.Width = 94;
            // 
            // gridColumn91
            // 
            this.gridColumn91.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn91.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn91.Caption = "Amt";
            this.gridColumn91.FieldName = "AMOUNT";
            this.gridColumn91.MinWidth = 25;
            this.gridColumn91.Name = "gridColumn91";
            this.gridColumn91.OptionsColumn.AllowEdit = false;
            this.gridColumn91.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn91.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "AMOUNT", "{0:0.##}")});
            this.gridColumn91.Visible = true;
            this.gridColumn91.VisibleIndex = 8;
            this.gridColumn91.Width = 94;
            // 
            // gridColumn92
            // 
            this.gridColumn92.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn92.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn92.Caption = "Remark";
            this.gridColumn92.FieldName = "REMARK";
            this.gridColumn92.MinWidth = 25;
            this.gridColumn92.Name = "gridColumn92";
            this.gridColumn92.OptionsColumn.AllowEdit = false;
            this.gridColumn92.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn92.Visible = true;
            this.gridColumn92.VisibleIndex = 9;
            this.gridColumn92.Width = 94;
            // 
            // gridColumn93
            // 
            this.gridColumn93.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn93.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn93.Caption = "Entry Date";
            this.gridColumn93.DisplayFormat.FormatString = "dd/MM/yyyy hh:mm:ss tt";
            this.gridColumn93.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn93.FieldName = "ENTRYDATE";
            this.gridColumn93.MinWidth = 25;
            this.gridColumn93.Name = "gridColumn93";
            this.gridColumn93.OptionsColumn.AllowEdit = false;
            this.gridColumn93.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn93.Visible = true;
            this.gridColumn93.VisibleIndex = 10;
            this.gridColumn93.Width = 220;
            // 
            // gridColumn101
            // 
            this.gridColumn101.Caption = "Delete";
            this.gridColumn101.ColumnEdit = this.BtnRejectionDelete;
            this.gridColumn101.FieldName = "DELETE";
            this.gridColumn101.MinWidth = 25;
            this.gridColumn101.Name = "gridColumn101";
            this.gridColumn101.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn101.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.gridColumn101.Visible = true;
            this.gridColumn101.VisibleIndex = 0;
            this.gridColumn101.Width = 94;
            // 
            // BtnRejectionDelete
            // 
            this.BtnRejectionDelete.AutoHeight = false;
            this.BtnRejectionDelete.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete)});
            this.BtnRejectionDelete.Name = "BtnRejectionDelete";
            this.BtnRejectionDelete.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.BtnRejectionDelete.Click += new System.EventHandler(this.BtnRejectionDelete_Click);
            // 
            // gridColumn102
            // 
            this.gridColumn102.Caption = "Update";
            this.gridColumn102.ColumnEdit = this.BtnRejectionUpdate;
            this.gridColumn102.FieldName = "UPDATE";
            this.gridColumn102.MinWidth = 25;
            this.gridColumn102.Name = "gridColumn102";
            this.gridColumn102.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn102.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.gridColumn102.Visible = true;
            this.gridColumn102.VisibleIndex = 1;
            this.gridColumn102.Width = 94;
            // 
            // BtnRejectionUpdate
            // 
            this.BtnRejectionUpdate.AutoHeight = false;
            this.BtnRejectionUpdate.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.BtnRejectionUpdate.Name = "BtnRejectionUpdate";
            this.BtnRejectionUpdate.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.BtnRejectionUpdate.Click += new System.EventHandler(this.BtnRejectionUpdate_Click);
            // 
            // repositoryItemButtonEdit3
            // 
            this.repositoryItemButtonEdit3.AutoHeight = false;
            this.repositoryItemButtonEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit3.Name = "repositoryItemButtonEdit3";
            // 
            // xtraTabPageMixSplit
            // 
            this.xtraTabPageMixSplit.Controls.Add(this.lblMixSplitDeleteLayout);
            this.xtraTabPageMixSplit.Controls.Add(this.lblMixSplitSaveLayout);
            this.xtraTabPageMixSplit.Controls.Add(this.MainGridMixSplit);
            this.xtraTabPageMixSplit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xtraTabPageMixSplit.Name = "xtraTabPageMixSplit";
            this.xtraTabPageMixSplit.Size = new System.Drawing.Size(1206, 178);
            this.xtraTabPageMixSplit.Text = "     MIX / SPLIT     ";
            // 
            // lblMixSplitDeleteLayout
            // 
            this.lblMixSplitDeleteLayout.AutoSize = true;
            this.lblMixSplitDeleteLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblMixSplitDeleteLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMixSplitDeleteLayout.ForeColor = System.Drawing.Color.Navy;
            this.lblMixSplitDeleteLayout.Location = new System.Drawing.Point(101, 6);
            this.lblMixSplitDeleteLayout.Name = "lblMixSplitDeleteLayout";
            this.lblMixSplitDeleteLayout.Size = new System.Drawing.Size(97, 13);
            this.lblMixSplitDeleteLayout.TabIndex = 151;
            this.lblMixSplitDeleteLayout.Text = "Delete Layout";
            this.lblMixSplitDeleteLayout.ToolTips = "";
            this.lblMixSplitDeleteLayout.Click += new System.EventHandler(this.lblMixSplitDeleteLayout_Click);
            // 
            // lblMixSplitSaveLayout
            // 
            this.lblMixSplitSaveLayout.AutoSize = true;
            this.lblMixSplitSaveLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblMixSplitSaveLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMixSplitSaveLayout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblMixSplitSaveLayout.Location = new System.Drawing.Point(8, 6);
            this.lblMixSplitSaveLayout.Name = "lblMixSplitSaveLayout";
            this.lblMixSplitSaveLayout.Size = new System.Drawing.Size(87, 13);
            this.lblMixSplitSaveLayout.TabIndex = 152;
            this.lblMixSplitSaveLayout.Text = "Save Layout";
            this.lblMixSplitSaveLayout.ToolTips = "";
            this.lblMixSplitSaveLayout.Click += new System.EventHandler(this.lblMixSplitSaveLayout_Click);
            // 
            // MainGridMixSplit
            // 
            this.MainGridMixSplit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainGridMixSplit.Location = new System.Drawing.Point(0, 0);
            this.MainGridMixSplit.MainView = this.GrdDetMixSplit;
            this.MainGridMixSplit.Name = "MainGridMixSplit";
            this.MainGridMixSplit.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.BtnMixSplitDelete});
            this.MainGridMixSplit.Size = new System.Drawing.Size(1206, 178);
            this.MainGridMixSplit.TabIndex = 3;
            this.MainGridMixSplit.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.GrdDetMixSplit});
            // 
            // GrdDetMixSplit
            // 
            this.GrdDetMixSplit.Appearance.FocusedCell.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDetMixSplit.Appearance.FocusedCell.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDetMixSplit.Appearance.FocusedCell.Font = new System.Drawing.Font("Verdana", 9F);
            this.GrdDetMixSplit.Appearance.FocusedCell.Options.UseBackColor = true;
            this.GrdDetMixSplit.Appearance.FocusedCell.Options.UseFont = true;
            this.GrdDetMixSplit.Appearance.FocusedRow.Font = new System.Drawing.Font("Verdana", 8F);
            this.GrdDetMixSplit.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GrdDetMixSplit.Appearance.FocusedRow.Options.UseFont = true;
            this.GrdDetMixSplit.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GrdDetMixSplit.Appearance.FooterPanel.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Bold);
            this.GrdDetMixSplit.Appearance.FooterPanel.Options.UseFont = true;
            this.GrdDetMixSplit.Appearance.HeaderPanel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold);
            this.GrdDetMixSplit.Appearance.HeaderPanel.Options.UseFont = true;
            this.GrdDetMixSplit.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.GrdDetMixSplit.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GrdDetMixSplit.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.GrdDetMixSplit.Appearance.HorzLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDetMixSplit.Appearance.HorzLine.Options.UseBackColor = true;
            this.GrdDetMixSplit.Appearance.Row.Font = new System.Drawing.Font("Verdana", 8F);
            this.GrdDetMixSplit.Appearance.Row.Options.UseFont = true;
            this.GrdDetMixSplit.Appearance.VertLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDetMixSplit.Appearance.VertLine.Options.UseBackColor = true;
            this.GrdDetMixSplit.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn61,
            this.gridColumn62,
            this.gridColumn63,
            this.gridColumn64,
            this.gridColumn65,
            this.gridColumn66,
            this.gridColumn67,
            this.gridColumn68,
            this.gridColumn69,
            this.gridColumn70,
            this.gridColumn71,
            this.gridColumn96,
            this.gridColumn97,
            this.gridColumn98});
            this.GrdDetMixSplit.DetailHeight = 431;
            this.GrdDetMixSplit.GridControl = this.MainGridMixSplit;
            this.GrdDetMixSplit.Name = "GrdDetMixSplit";
            this.GrdDetMixSplit.OptionsCustomization.AllowSort = false;
            this.GrdDetMixSplit.OptionsFilter.AllowFilterEditor = false;
            this.GrdDetMixSplit.OptionsPrint.ExpandAllGroups = false;
            this.GrdDetMixSplit.OptionsView.ColumnAutoWidth = false;
            this.GrdDetMixSplit.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.GrdDetMixSplit.OptionsView.ShowFooter = true;
            this.GrdDetMixSplit.OptionsView.ShowGroupPanel = false;
            this.GrdDetMixSplit.OptionsView.ShowViewCaption = true;
            this.GrdDetMixSplit.ViewCaption = "Mix Split Lot Details";
            // 
            // gridColumn61
            // 
            this.gridColumn61.Caption = "Trn ID";
            this.gridColumn61.FieldName = "TRN_ID";
            this.gridColumn61.MinWidth = 25;
            this.gridColumn61.Name = "gridColumn61";
            this.gridColumn61.OptionsColumn.AllowEdit = false;
            this.gridColumn61.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn61.Width = 94;
            // 
            // gridColumn62
            // 
            this.gridColumn62.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn62.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn62.Caption = "Operation";
            this.gridColumn62.FieldName = "OPERATION";
            this.gridColumn62.MinWidth = 25;
            this.gridColumn62.Name = "gridColumn62";
            this.gridColumn62.OptionsColumn.AllowEdit = false;
            this.gridColumn62.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn62.Visible = true;
            this.gridColumn62.VisibleIndex = 1;
            this.gridColumn62.Width = 129;
            // 
            // gridColumn63
            // 
            this.gridColumn63.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn63.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn63.Caption = "Description";
            this.gridColumn63.FieldName = "OPEDESC";
            this.gridColumn63.MinWidth = 25;
            this.gridColumn63.Name = "gridColumn63";
            this.gridColumn63.OptionsColumn.AllowEdit = false;
            this.gridColumn63.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn63.Visible = true;
            this.gridColumn63.VisibleIndex = 2;
            this.gridColumn63.Width = 236;
            // 
            // gridColumn64
            // 
            this.gridColumn64.Caption = "LOT_ID";
            this.gridColumn64.FieldName = "LOT_ID";
            this.gridColumn64.MinWidth = 25;
            this.gridColumn64.Name = "gridColumn64";
            this.gridColumn64.OptionsColumn.AllowEdit = false;
            this.gridColumn64.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn64.Width = 94;
            // 
            // gridColumn65
            // 
            this.gridColumn65.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn65.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn65.Caption = "Lot No";
            this.gridColumn65.FieldName = "LOTNO";
            this.gridColumn65.MinWidth = 25;
            this.gridColumn65.Name = "gridColumn65";
            this.gridColumn65.OptionsColumn.AllowEdit = false;
            this.gridColumn65.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn65.Visible = true;
            this.gridColumn65.VisibleIndex = 3;
            this.gridColumn65.Width = 94;
            // 
            // gridColumn66
            // 
            this.gridColumn66.Caption = "REFLOT_ID";
            this.gridColumn66.FieldName = "REFLOT_ID";
            this.gridColumn66.MinWidth = 25;
            this.gridColumn66.Name = "gridColumn66";
            this.gridColumn66.OptionsColumn.AllowEdit = false;
            this.gridColumn66.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn66.Width = 94;
            // 
            // gridColumn67
            // 
            this.gridColumn67.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn67.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn67.Caption = "Ref Lot No";
            this.gridColumn67.FieldName = "REFLOTNO";
            this.gridColumn67.MinWidth = 25;
            this.gridColumn67.Name = "gridColumn67";
            this.gridColumn67.OptionsColumn.AllowEdit = false;
            this.gridColumn67.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn67.Visible = true;
            this.gridColumn67.VisibleIndex = 4;
            this.gridColumn67.Width = 94;
            // 
            // gridColumn68
            // 
            this.gridColumn68.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn68.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn68.Caption = "Trf Carat";
            this.gridColumn68.FieldName = "TOTALTRFCARAT";
            this.gridColumn68.MinWidth = 25;
            this.gridColumn68.Name = "gridColumn68";
            this.gridColumn68.OptionsColumn.AllowEdit = false;
            this.gridColumn68.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn68.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TOTALTRFCARAT", "{0:0.##}")});
            this.gridColumn68.Visible = true;
            this.gridColumn68.VisibleIndex = 5;
            this.gridColumn68.Width = 94;
            // 
            // gridColumn69
            // 
            this.gridColumn69.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn69.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn69.Caption = "Trf Rate";
            this.gridColumn69.FieldName = "TOTALTRFRATE";
            this.gridColumn69.MinWidth = 25;
            this.gridColumn69.Name = "gridColumn69";
            this.gridColumn69.OptionsColumn.AllowEdit = false;
            this.gridColumn69.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn69.Visible = true;
            this.gridColumn69.VisibleIndex = 6;
            this.gridColumn69.Width = 94;
            // 
            // gridColumn70
            // 
            this.gridColumn70.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn70.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn70.Caption = "Trf Amount";
            this.gridColumn70.FieldName = "TOTALTRFAMOUNT";
            this.gridColumn70.MinWidth = 25;
            this.gridColumn70.Name = "gridColumn70";
            this.gridColumn70.OptionsColumn.AllowEdit = false;
            this.gridColumn70.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn70.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TOTALTRFAMOUNT", "{0:0.##}")});
            this.gridColumn70.Visible = true;
            this.gridColumn70.VisibleIndex = 7;
            this.gridColumn70.Width = 134;
            // 
            // gridColumn71
            // 
            this.gridColumn71.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn71.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn71.Caption = "Exc Rate";
            this.gridColumn71.FieldName = "TOEXCRATE";
            this.gridColumn71.MinWidth = 25;
            this.gridColumn71.Name = "gridColumn71";
            this.gridColumn71.OptionsColumn.AllowEdit = false;
            this.gridColumn71.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn71.Visible = true;
            this.gridColumn71.VisibleIndex = 8;
            this.gridColumn71.Width = 94;
            // 
            // gridColumn96
            // 
            this.gridColumn96.Caption = "Entry Date";
            this.gridColumn96.DisplayFormat.FormatString = "dd/MM/yyyy hh:mm:ss tt";
            this.gridColumn96.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn96.FieldName = "ENTRYDATE";
            this.gridColumn96.MinWidth = 25;
            this.gridColumn96.Name = "gridColumn96";
            this.gridColumn96.OptionsColumn.AllowEdit = false;
            this.gridColumn96.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn96.Visible = true;
            this.gridColumn96.VisibleIndex = 9;
            this.gridColumn96.Width = 253;
            // 
            // gridColumn97
            // 
            this.gridColumn97.Caption = "Delete";
            this.gridColumn97.ColumnEdit = this.BtnMixSplitDelete;
            this.gridColumn97.FieldName = "DELETE";
            this.gridColumn97.MinWidth = 25;
            this.gridColumn97.Name = "gridColumn97";
            this.gridColumn97.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn97.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.gridColumn97.Visible = true;
            this.gridColumn97.VisibleIndex = 0;
            this.gridColumn97.Width = 94;
            // 
            // BtnMixSplitDelete
            // 
            this.BtnMixSplitDelete.AutoHeight = false;
            this.BtnMixSplitDelete.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete)});
            this.BtnMixSplitDelete.Name = "BtnMixSplitDelete";
            this.BtnMixSplitDelete.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.BtnMixSplitDelete.Click += new System.EventHandler(this.BtnMixSplitDelete_Click);
            // 
            // gridColumn98
            // 
            this.gridColumn98.Caption = "SrNo";
            this.gridColumn98.FieldName = "SRNO";
            this.gridColumn98.MinWidth = 25;
            this.gridColumn98.Name = "gridColumn98";
            this.gridColumn98.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn98.Width = 94;
            // 
            // xtraTabPageKapan
            // 
            this.xtraTabPageKapan.Controls.Add(this.lblKapanDeleteLayout);
            this.xtraTabPageKapan.Controls.Add(this.lblKapanSaveLayout);
            this.xtraTabPageKapan.Controls.Add(this.MainGridKapan);
            this.xtraTabPageKapan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xtraTabPageKapan.Name = "xtraTabPageKapan";
            this.xtraTabPageKapan.Size = new System.Drawing.Size(1206, 178);
            this.xtraTabPageKapan.Text = "     KAPAN     ";
            // 
            // lblKapanDeleteLayout
            // 
            this.lblKapanDeleteLayout.AutoSize = true;
            this.lblKapanDeleteLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblKapanDeleteLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKapanDeleteLayout.ForeColor = System.Drawing.Color.Navy;
            this.lblKapanDeleteLayout.Location = new System.Drawing.Point(96, 5);
            this.lblKapanDeleteLayout.Name = "lblKapanDeleteLayout";
            this.lblKapanDeleteLayout.Size = new System.Drawing.Size(97, 13);
            this.lblKapanDeleteLayout.TabIndex = 153;
            this.lblKapanDeleteLayout.Text = "Delete Layout";
            this.lblKapanDeleteLayout.ToolTips = "";
            this.lblKapanDeleteLayout.Click += new System.EventHandler(this.lblKapanDeleteLayout_Click);
            // 
            // lblKapanSaveLayout
            // 
            this.lblKapanSaveLayout.AutoSize = true;
            this.lblKapanSaveLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblKapanSaveLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKapanSaveLayout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblKapanSaveLayout.Location = new System.Drawing.Point(3, 5);
            this.lblKapanSaveLayout.Name = "lblKapanSaveLayout";
            this.lblKapanSaveLayout.Size = new System.Drawing.Size(87, 13);
            this.lblKapanSaveLayout.TabIndex = 154;
            this.lblKapanSaveLayout.Text = "Save Layout";
            this.lblKapanSaveLayout.ToolTips = "";
            this.lblKapanSaveLayout.Click += new System.EventHandler(this.lblKapanSaveLayout_Click);
            // 
            // MainGridKapan
            // 
            this.MainGridKapan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainGridKapan.Location = new System.Drawing.Point(0, 0);
            this.MainGridKapan.MainView = this.GrdDetKapan;
            this.MainGridKapan.Name = "MainGridKapan";
            this.MainGridKapan.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.BtnKapanDelete,
            this.BtnKapanUpdate,
            this.CmbKapanStatus,
            this.txtManager,
            this.btnKapanValuation});
            this.MainGridKapan.Size = new System.Drawing.Size(1206, 178);
            this.MainGridKapan.TabIndex = 4;
            this.MainGridKapan.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.GrdDetKapan});
            // 
            // GrdDetKapan
            // 
            this.GrdDetKapan.Appearance.FocusedCell.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDetKapan.Appearance.FocusedCell.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDetKapan.Appearance.FocusedCell.Font = new System.Drawing.Font("Verdana", 9F);
            this.GrdDetKapan.Appearance.FocusedCell.Options.UseBackColor = true;
            this.GrdDetKapan.Appearance.FocusedCell.Options.UseFont = true;
            this.GrdDetKapan.Appearance.FocusedRow.Font = new System.Drawing.Font("Verdana", 8F);
            this.GrdDetKapan.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GrdDetKapan.Appearance.FocusedRow.Options.UseFont = true;
            this.GrdDetKapan.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GrdDetKapan.Appearance.FooterPanel.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Bold);
            this.GrdDetKapan.Appearance.FooterPanel.Options.UseFont = true;
            this.GrdDetKapan.Appearance.HeaderPanel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold);
            this.GrdDetKapan.Appearance.HeaderPanel.Options.UseFont = true;
            this.GrdDetKapan.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.GrdDetKapan.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GrdDetKapan.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.GrdDetKapan.Appearance.HorzLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDetKapan.Appearance.HorzLine.Options.UseBackColor = true;
            this.GrdDetKapan.Appearance.Row.Font = new System.Drawing.Font("Verdana", 8F);
            this.GrdDetKapan.Appearance.Row.Options.UseFont = true;
            this.GrdDetKapan.Appearance.VertLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDetKapan.Appearance.VertLine.Options.UseBackColor = true;
            this.GrdDetKapan.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn72,
            this.gridColumn73,
            this.gridColumn74,
            this.gridColumn128,
            this.gridColumn75,
            this.gridColumn76,
            this.gridColumn77,
            this.gridColumn78,
            this.gridColumn79,
            this.gridColumn80,
            this.gridColumn81,
            this.gridColumn82,
            this.gridColumn94,
            this.gridColumn95,
            this.gridColumn99,
            this.gridColumn100,
            this.gridColumn103,
            this.gridColumn104,
            this.gridColumn105,
            this.gridColumn106,
            this.gridColumn107,
            this.gridColumn129,
            this.gridColumn130,
            this.gridColumn131,
            this.gridColumn132,
            this.gridColumn133,
            this.gridColumn135,
            this.gridColumn139,
            this.gridColumn140,
            this.gridColumn141,
            this.gridColumn142,
            this.gridColumn143,
            this.gridColumn144});
            this.GrdDetKapan.DetailHeight = 431;
            this.GrdDetKapan.GridControl = this.MainGridKapan;
            this.GrdDetKapan.Name = "GrdDetKapan";
            this.GrdDetKapan.OptionsCustomization.AllowSort = false;
            this.GrdDetKapan.OptionsFilter.AllowFilterEditor = false;
            this.GrdDetKapan.OptionsPrint.ExpandAllGroups = false;
            this.GrdDetKapan.OptionsView.ColumnAutoWidth = false;
            this.GrdDetKapan.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.GrdDetKapan.OptionsView.ShowFooter = true;
            this.GrdDetKapan.OptionsView.ShowGroupPanel = false;
            this.GrdDetKapan.OptionsView.ShowViewCaption = true;
            this.GrdDetKapan.ViewCaption = "Kapan Detail";
            this.GrdDetKapan.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.GrdDetKapan_CustomSummaryCalculate);
            this.GrdDetKapan.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.GrdDetKapan_CellValueChanged);
            // 
            // gridColumn72
            // 
            this.gridColumn72.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn72.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn72.Caption = "KAPAN_ID";
            this.gridColumn72.FieldName = "KAPAN_ID";
            this.gridColumn72.MinWidth = 25;
            this.gridColumn72.Name = "gridColumn72";
            this.gridColumn72.OptionsColumn.AllowEdit = false;
            this.gridColumn72.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn72.Width = 94;
            // 
            // gridColumn73
            // 
            this.gridColumn73.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn73.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn73.Caption = "Lot No";
            this.gridColumn73.FieldName = "LOTNO";
            this.gridColumn73.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn73.MinWidth = 25;
            this.gridColumn73.Name = "gridColumn73";
            this.gridColumn73.OptionsColumn.AllowEdit = false;
            this.gridColumn73.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn73.Visible = true;
            this.gridColumn73.VisibleIndex = 2;
            this.gridColumn73.Width = 94;
            // 
            // gridColumn74
            // 
            this.gridColumn74.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn74.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn74.Caption = "Kapan";
            this.gridColumn74.FieldName = "KAPANNAME";
            this.gridColumn74.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn74.MinWidth = 25;
            this.gridColumn74.Name = "gridColumn74";
            this.gridColumn74.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn74.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count)});
            this.gridColumn74.Visible = true;
            this.gridColumn74.VisibleIndex = 3;
            this.gridColumn74.Width = 94;
            // 
            // gridColumn128
            // 
            this.gridColumn128.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn128.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn128.Caption = "Group";
            this.gridColumn128.FieldName = "KAPANGROUP";
            this.gridColumn128.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn128.Name = "gridColumn128";
            this.gridColumn128.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn128.Visible = true;
            this.gridColumn128.VisibleIndex = 4;
            // 
            // gridColumn75
            // 
            this.gridColumn75.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn75.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn75.Caption = "MANAGER_ID";
            this.gridColumn75.FieldName = "MANAGER_ID";
            this.gridColumn75.MinWidth = 25;
            this.gridColumn75.Name = "gridColumn75";
            this.gridColumn75.OptionsColumn.AllowEdit = false;
            this.gridColumn75.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn75.Width = 94;
            // 
            // gridColumn76
            // 
            this.gridColumn76.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn76.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn76.Caption = "Ownership";
            this.gridColumn76.ColumnEdit = this.txtManager;
            this.gridColumn76.FieldName = "MANAGERNAME";
            this.gridColumn76.MinWidth = 25;
            this.gridColumn76.Name = "gridColumn76";
            this.gridColumn76.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn76.Visible = true;
            this.gridColumn76.VisibleIndex = 5;
            this.gridColumn76.Width = 147;
            // 
            // txtManager
            // 
            this.txtManager.AutoHeight = false;
            this.txtManager.Name = "txtManager";
            this.txtManager.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtManager_KeyPress);
            // 
            // gridColumn77
            // 
            this.gridColumn77.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn77.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn77.Caption = "Kapan Date";
            this.gridColumn77.FieldName = "KAPANDATE";
            this.gridColumn77.MinWidth = 25;
            this.gridColumn77.Name = "gridColumn77";
            this.gridColumn77.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn77.Visible = true;
            this.gridColumn77.VisibleIndex = 6;
            this.gridColumn77.Width = 155;
            // 
            // gridColumn78
            // 
            this.gridColumn78.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn78.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn78.Caption = "Pcs";
            this.gridColumn78.FieldName = "KAPANPCS";
            this.gridColumn78.MinWidth = 25;
            this.gridColumn78.Name = "gridColumn78";
            this.gridColumn78.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn78.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum)});
            this.gridColumn78.Visible = true;
            this.gridColumn78.VisibleIndex = 7;
            this.gridColumn78.Width = 94;
            // 
            // gridColumn79
            // 
            this.gridColumn79.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn79.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn79.Caption = "Carat";
            this.gridColumn79.FieldName = "KAPANCARAT";
            this.gridColumn79.MinWidth = 25;
            this.gridColumn79.Name = "gridColumn79";
            this.gridColumn79.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn79.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum)});
            this.gridColumn79.Visible = true;
            this.gridColumn79.VisibleIndex = 8;
            this.gridColumn79.Width = 94;
            // 
            // gridColumn80
            // 
            this.gridColumn80.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn80.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn80.Caption = "Rate";
            this.gridColumn80.FieldName = "KAPANRATE";
            this.gridColumn80.MinWidth = 25;
            this.gridColumn80.Name = "gridColumn80";
            this.gridColumn80.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn80.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count)});
            this.gridColumn80.Visible = true;
            this.gridColumn80.VisibleIndex = 9;
            this.gridColumn80.Width = 94;
            // 
            // gridColumn81
            // 
            this.gridColumn81.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn81.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn81.Caption = "Amount";
            this.gridColumn81.FieldName = "KAPANAMOUNT";
            this.gridColumn81.MinWidth = 25;
            this.gridColumn81.Name = "gridColumn81";
            this.gridColumn81.OptionsColumn.AllowEdit = false;
            this.gridColumn81.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn81.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum)});
            this.gridColumn81.Visible = true;
            this.gridColumn81.VisibleIndex = 10;
            this.gridColumn81.Width = 94;
            // 
            // gridColumn82
            // 
            this.gridColumn82.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn82.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn82.Caption = "Bal. Pcs";
            this.gridColumn82.FieldName = "BALANCEPCS";
            this.gridColumn82.MinWidth = 25;
            this.gridColumn82.Name = "gridColumn82";
            this.gridColumn82.OptionsColumn.AllowEdit = false;
            this.gridColumn82.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn82.Width = 94;
            // 
            // gridColumn94
            // 
            this.gridColumn94.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn94.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn94.Caption = "Bal Carat";
            this.gridColumn94.FieldName = "BALANCECARAT";
            this.gridColumn94.MinWidth = 25;
            this.gridColumn94.Name = "gridColumn94";
            this.gridColumn94.OptionsColumn.AllowEdit = false;
            this.gridColumn94.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn94.Width = 94;
            // 
            // gridColumn95
            // 
            this.gridColumn95.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn95.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn95.Caption = "Entry Date";
            this.gridColumn95.DisplayFormat.FormatString = "dd/MM/yyyy hh:mm:ss tt";
            this.gridColumn95.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn95.FieldName = "ENTRYDATE";
            this.gridColumn95.MinWidth = 25;
            this.gridColumn95.Name = "gridColumn95";
            this.gridColumn95.OptionsColumn.AllowEdit = false;
            this.gridColumn95.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn95.Width = 199;
            // 
            // gridColumn99
            // 
            this.gridColumn99.Caption = "Delete";
            this.gridColumn99.ColumnEdit = this.BtnKapanDelete;
            this.gridColumn99.FieldName = "DELETE";
            this.gridColumn99.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn99.MinWidth = 25;
            this.gridColumn99.Name = "gridColumn99";
            this.gridColumn99.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn99.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.gridColumn99.Visible = true;
            this.gridColumn99.VisibleIndex = 0;
            this.gridColumn99.Width = 94;
            // 
            // BtnKapanDelete
            // 
            this.BtnKapanDelete.AutoHeight = false;
            this.BtnKapanDelete.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete)});
            this.BtnKapanDelete.Name = "BtnKapanDelete";
            this.BtnKapanDelete.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.BtnKapanDelete.Click += new System.EventHandler(this.BtnKapanDelete_Click);
            // 
            // gridColumn100
            // 
            this.gridColumn100.Caption = "Update";
            this.gridColumn100.ColumnEdit = this.BtnKapanUpdate;
            this.gridColumn100.FieldName = "UPDATE";
            this.gridColumn100.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn100.MinWidth = 25;
            this.gridColumn100.Name = "gridColumn100";
            this.gridColumn100.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn100.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.gridColumn100.Visible = true;
            this.gridColumn100.VisibleIndex = 1;
            this.gridColumn100.Width = 94;
            // 
            // BtnKapanUpdate
            // 
            this.BtnKapanUpdate.AutoHeight = false;
            this.BtnKapanUpdate.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.BtnKapanUpdate.Name = "BtnKapanUpdate";
            this.BtnKapanUpdate.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.BtnKapanUpdate.Click += new System.EventHandler(this.BtnKapanUpdate_Click);
            // 
            // gridColumn103
            // 
            this.gridColumn103.Caption = "Status";
            this.gridColumn103.ColumnEdit = this.CmbKapanStatus;
            this.gridColumn103.FieldName = "STATUS";
            this.gridColumn103.MinWidth = 25;
            this.gridColumn103.Name = "gridColumn103";
            this.gridColumn103.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn103.Width = 94;
            // 
            // CmbKapanStatus
            // 
            this.CmbKapanStatus.AutoHeight = false;
            this.CmbKapanStatus.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.CmbKapanStatus.Items.AddRange(new object[] {
            "PENDING",
            "RUNNING",
            "COMPLETE"});
            this.CmbKapanStatus.Name = "CmbKapanStatus";
            this.CmbKapanStatus.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // gridColumn104
            // 
            this.gridColumn104.Caption = "ISHide";
            this.gridColumn104.FieldName = "ISHIDE";
            this.gridColumn104.MinWidth = 25;
            this.gridColumn104.Name = "gridColumn104";
            this.gridColumn104.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn104.Visible = true;
            this.gridColumn104.VisibleIndex = 17;
            this.gridColumn104.Width = 94;
            // 
            // gridColumn105
            // 
            this.gridColumn105.Caption = "ISNotApplyAnyLock";
            this.gridColumn105.FieldName = "ISNOTAPPLYANYLOCK";
            this.gridColumn105.MinWidth = 25;
            this.gridColumn105.Name = "gridColumn105";
            this.gridColumn105.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn105.Visible = true;
            this.gridColumn105.VisibleIndex = 18;
            this.gridColumn105.Width = 164;
            // 
            // gridColumn106
            // 
            this.gridColumn106.Caption = "Labour Amount";
            this.gridColumn106.FieldName = "LABOURAMOUNT";
            this.gridColumn106.MinWidth = 25;
            this.gridColumn106.Name = "gridColumn106";
            this.gridColumn106.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn106.Visible = true;
            this.gridColumn106.VisibleIndex = 19;
            this.gridColumn106.Width = 130;
            // 
            // gridColumn107
            // 
            this.gridColumn107.Caption = "Complete Date";
            this.gridColumn107.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn107.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn107.FieldName = "COMPLETEDATE";
            this.gridColumn107.MinWidth = 25;
            this.gridColumn107.Name = "gridColumn107";
            this.gridColumn107.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn107.Width = 94;
            // 
            // gridColumn129
            // 
            this.gridColumn129.Caption = "ClvCompleteDate";
            this.gridColumn129.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn129.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn129.FieldName = "CLVCOMPLETEDATE";
            this.gridColumn129.Name = "gridColumn129";
            this.gridColumn129.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn129.Visible = true;
            this.gridColumn129.VisibleIndex = 11;
            this.gridColumn129.Width = 141;
            // 
            // gridColumn130
            // 
            this.gridColumn130.Caption = "MFGIssueDate";
            this.gridColumn130.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn130.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn130.FieldName = "MFGISSUEDATE";
            this.gridColumn130.Name = "gridColumn130";
            this.gridColumn130.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn130.Visible = true;
            this.gridColumn130.VisibleIndex = 12;
            this.gridColumn130.Width = 126;
            // 
            // gridColumn131
            // 
            this.gridColumn131.Caption = "GhatCompleteDate";
            this.gridColumn131.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn131.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn131.FieldName = "GHATCOMPLETEDATE";
            this.gridColumn131.Name = "gridColumn131";
            this.gridColumn131.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn131.Visible = true;
            this.gridColumn131.VisibleIndex = 13;
            this.gridColumn131.Width = 128;
            // 
            // gridColumn132
            // 
            this.gridColumn132.Caption = "MumbaiRecvDate ";
            this.gridColumn132.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn132.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn132.FieldName = "MUMBAIRECVDATE";
            this.gridColumn132.Name = "gridColumn132";
            this.gridColumn132.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn132.Visible = true;
            this.gridColumn132.VisibleIndex = 15;
            this.gridColumn132.Width = 147;
            // 
            // gridColumn133
            // 
            this.gridColumn133.Caption = "PolishRecvDate ";
            this.gridColumn133.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.gridColumn133.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn133.FieldName = "POLISHRECVDATE";
            this.gridColumn133.Name = "gridColumn133";
            this.gridColumn133.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn133.Visible = true;
            this.gridColumn133.VisibleIndex = 14;
            this.gridColumn133.Width = 144;
            // 
            // gridColumn135
            // 
            this.gridColumn135.Caption = "Kapan Valuation";
            this.gridColumn135.ColumnEdit = this.btnKapanValuation;
            this.gridColumn135.Name = "gridColumn135";
            this.gridColumn135.Visible = true;
            this.gridColumn135.VisibleIndex = 16;
            this.gridColumn135.Width = 154;
            // 
            // btnKapanValuation
            // 
            this.btnKapanValuation.AutoHeight = false;
            this.btnKapanValuation.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus)});
            this.btnKapanValuation.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.btnKapanValuation.Name = "btnKapanValuation";
            this.btnKapanValuation.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.btnKapanValuation.Click += new System.EventHandler(this.btnKapanValuation_Click);
            // 
            // gridColumn139
            // 
            this.gridColumn139.Caption = "LOTCONVRATE";
            this.gridColumn139.FieldName = "LOTCONVRATE";
            this.gridColumn139.Name = "gridColumn139";
            // 
            // gridColumn140
            // 
            this.gridColumn140.Caption = "POLISHCONVRATE";
            this.gridColumn140.FieldName = "POLISHCONVRATE";
            this.gridColumn140.Name = "gridColumn140";
            // 
            // gridColumn141
            // 
            this.gridColumn141.Caption = "POLISHAVG";
            this.gridColumn141.FieldName = "POLISHAVG";
            this.gridColumn141.Name = "gridColumn141";
            // 
            // gridColumn142
            // 
            this.gridColumn142.Caption = "OTHERMFGEXPENSE";
            this.gridColumn142.FieldName = "OTHERMFGEXPENSE";
            this.gridColumn142.Name = "gridColumn142";
            // 
            // gridColumn143
            // 
            this.gridColumn143.Caption = "LOTCONVRATE";
            this.gridColumn143.FieldName = "LOTCONVRATE";
            this.gridColumn143.Name = "gridColumn143";
            // 
            // gridColumn144
            // 
            this.gridColumn144.Caption = "LABRATE";
            this.gridColumn144.FieldName = "LABRATE";
            this.gridColumn144.Name = "gridColumn144";
            // 
            // xtraTabPageSale
            // 
            this.xtraTabPageSale.Controls.Add(this.lblSaleEntryDeletLayout);
            this.xtraTabPageSale.Controls.Add(this.lblSaleEntrySaveLayout);
            this.xtraTabPageSale.Controls.Add(this.MainGridSale);
            this.xtraTabPageSale.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xtraTabPageSale.Name = "xtraTabPageSale";
            this.xtraTabPageSale.Size = new System.Drawing.Size(1206, 178);
            this.xtraTabPageSale.Text = "   SALE ENTRY   ";
            // 
            // lblSaleEntryDeletLayout
            // 
            this.lblSaleEntryDeletLayout.AutoSize = true;
            this.lblSaleEntryDeletLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSaleEntryDeletLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleEntryDeletLayout.ForeColor = System.Drawing.Color.Navy;
            this.lblSaleEntryDeletLayout.Location = new System.Drawing.Point(102, 6);
            this.lblSaleEntryDeletLayout.Name = "lblSaleEntryDeletLayout";
            this.lblSaleEntryDeletLayout.Size = new System.Drawing.Size(97, 13);
            this.lblSaleEntryDeletLayout.TabIndex = 153;
            this.lblSaleEntryDeletLayout.Text = "Delete Layout";
            this.lblSaleEntryDeletLayout.ToolTips = "";
            this.lblSaleEntryDeletLayout.Click += new System.EventHandler(this.lblSaleEntryDeletLayout_Click);
            // 
            // lblSaleEntrySaveLayout
            // 
            this.lblSaleEntrySaveLayout.AutoSize = true;
            this.lblSaleEntrySaveLayout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSaleEntrySaveLayout.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleEntrySaveLayout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblSaleEntrySaveLayout.Location = new System.Drawing.Point(9, 6);
            this.lblSaleEntrySaveLayout.Name = "lblSaleEntrySaveLayout";
            this.lblSaleEntrySaveLayout.Size = new System.Drawing.Size(87, 13);
            this.lblSaleEntrySaveLayout.TabIndex = 154;
            this.lblSaleEntrySaveLayout.Text = "Save Layout";
            this.lblSaleEntrySaveLayout.ToolTips = "";
            this.lblSaleEntrySaveLayout.Click += new System.EventHandler(this.lblSaleEntrySaveLayout_Click);
            // 
            // MainGridSale
            // 
            this.MainGridSale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainGridSale.Location = new System.Drawing.Point(0, 0);
            this.MainGridSale.MainView = this.GrdDetSale;
            this.MainGridSale.Name = "MainGridSale";
            this.MainGridSale.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEdit1,
            this.repositoryItemButtonEdit2,
            this.repositoryItemTextEdit1});
            this.MainGridSale.Size = new System.Drawing.Size(1206, 178);
            this.MainGridSale.TabIndex = 6;
            this.MainGridSale.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.GrdDetSale});
            // 
            // GrdDetSale
            // 
            this.GrdDetSale.Appearance.FocusedCell.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDetSale.Appearance.FocusedCell.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(234)))), ((int)(((byte)(141)))));
            this.GrdDetSale.Appearance.FocusedCell.Font = new System.Drawing.Font("Verdana", 9F);
            this.GrdDetSale.Appearance.FocusedCell.Options.UseBackColor = true;
            this.GrdDetSale.Appearance.FocusedCell.Options.UseFont = true;
            this.GrdDetSale.Appearance.FocusedRow.Font = new System.Drawing.Font("Verdana", 8F);
            this.GrdDetSale.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GrdDetSale.Appearance.FocusedRow.Options.UseFont = true;
            this.GrdDetSale.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GrdDetSale.Appearance.FooterPanel.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Bold);
            this.GrdDetSale.Appearance.FooterPanel.Options.UseFont = true;
            this.GrdDetSale.Appearance.HeaderPanel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold);
            this.GrdDetSale.Appearance.HeaderPanel.Options.UseFont = true;
            this.GrdDetSale.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.GrdDetSale.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.GrdDetSale.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.GrdDetSale.Appearance.HorzLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDetSale.Appearance.HorzLine.Options.UseBackColor = true;
            this.GrdDetSale.Appearance.Row.Font = new System.Drawing.Font("Verdana", 8F);
            this.GrdDetSale.Appearance.Row.Options.UseFont = true;
            this.GrdDetSale.Appearance.VertLine.BackColor = System.Drawing.Color.Gray;
            this.GrdDetSale.Appearance.VertLine.Options.UseBackColor = true;
            this.GrdDetSale.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn109,
            this.gridColumn110,
            this.gridColumn111,
            this.gridColumn112,
            this.gridColumn113,
            this.gridColumn114,
            this.gridColumn115,
            this.gridColumn116,
            this.gridColumn127,
            this.gridColumn117,
            this.gridColumn118,
            this.gridColumn119,
            this.gridColumn120,
            this.gridColumn121,
            this.gridColumn122,
            this.gridColumn123,
            this.gridColumn124,
            this.gridColumn125,
            this.gridColumn126,
            this.gridColumn145,
            this.gridColumn146});
            this.GrdDetSale.DetailHeight = 431;
            this.GrdDetSale.GridControl = this.MainGridSale;
            this.GrdDetSale.Name = "GrdDetSale";
            this.GrdDetSale.OptionsCustomization.AllowSort = false;
            this.GrdDetSale.OptionsFilter.AllowFilterEditor = false;
            this.GrdDetSale.OptionsPrint.ExpandAllGroups = false;
            this.GrdDetSale.OptionsView.ColumnAutoWidth = false;
            this.GrdDetSale.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.GrdDetSale.OptionsView.ShowFooter = true;
            this.GrdDetSale.OptionsView.ShowGroupPanel = false;
            this.GrdDetSale.OptionsView.ShowViewCaption = true;
            this.GrdDetSale.ViewCaption = "Sale Detail";
            this.GrdDetSale.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.GrdDetSale_CustomSummaryCalculate);
            // 
            // gridColumn109
            // 
            this.gridColumn109.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn109.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn109.Caption = "Lot Description";
            this.gridColumn109.FieldName = "LOTDESCRIPTION";
            this.gridColumn109.MinWidth = 25;
            this.gridColumn109.Name = "gridColumn109";
            this.gridColumn109.OptionsColumn.AllowEdit = false;
            this.gridColumn109.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn109.Visible = true;
            this.gridColumn109.VisibleIndex = 0;
            this.gridColumn109.Width = 126;
            // 
            // gridColumn110
            // 
            this.gridColumn110.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn110.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn110.Caption = "INVOICE_ID";
            this.gridColumn110.FieldName = "INVOICE_ID";
            this.gridColumn110.MinWidth = 25;
            this.gridColumn110.Name = "gridColumn110";
            this.gridColumn110.OptionsColumn.AllowEdit = false;
            this.gridColumn110.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn110.Width = 94;
            // 
            // gridColumn111
            // 
            this.gridColumn111.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn111.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn111.Caption = "SALE_ID";
            this.gridColumn111.FieldName = "SALE_ID";
            this.gridColumn111.MinWidth = 25;
            this.gridColumn111.Name = "gridColumn111";
            this.gridColumn111.OptionsColumn.AllowEdit = false;
            this.gridColumn111.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn111.Width = 94;
            // 
            // gridColumn112
            // 
            this.gridColumn112.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn112.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn112.Caption = "Invoice Date";
            this.gridColumn112.FieldName = "INVOICEDATE";
            this.gridColumn112.MinWidth = 25;
            this.gridColumn112.Name = "gridColumn112";
            this.gridColumn112.OptionsColumn.AllowEdit = false;
            this.gridColumn112.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn112.Visible = true;
            this.gridColumn112.VisibleIndex = 1;
            this.gridColumn112.Width = 167;
            // 
            // gridColumn113
            // 
            this.gridColumn113.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn113.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn113.Caption = "Manual Invoice No";
            this.gridColumn113.FieldName = "MANUALINVOICENO";
            this.gridColumn113.MinWidth = 25;
            this.gridColumn113.Name = "gridColumn113";
            this.gridColumn113.OptionsColumn.AllowEdit = false;
            this.gridColumn113.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn113.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count)});
            this.gridColumn113.Visible = true;
            this.gridColumn113.VisibleIndex = 2;
            this.gridColumn113.Width = 147;
            // 
            // gridColumn114
            // 
            this.gridColumn114.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn114.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn114.Caption = "Party Name";
            this.gridColumn114.FieldName = "PARTYNAME";
            this.gridColumn114.MinWidth = 25;
            this.gridColumn114.Name = "gridColumn114";
            this.gridColumn114.OptionsColumn.AllowEdit = false;
            this.gridColumn114.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn114.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "PCS", "{0:0.##}")});
            this.gridColumn114.Visible = true;
            this.gridColumn114.VisibleIndex = 3;
            this.gridColumn114.Width = 98;
            // 
            // gridColumn115
            // 
            this.gridColumn115.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn115.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn115.Caption = "Pcs";
            this.gridColumn115.FieldName = "PCS";
            this.gridColumn115.MinWidth = 25;
            this.gridColumn115.Name = "gridColumn115";
            this.gridColumn115.OptionsColumn.AllowEdit = false;
            this.gridColumn115.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn115.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "CARAT", "{0:0.##}")});
            this.gridColumn115.Visible = true;
            this.gridColumn115.VisibleIndex = 4;
            this.gridColumn115.Width = 94;
            // 
            // gridColumn116
            // 
            this.gridColumn116.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn116.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn116.Caption = "Carat";
            this.gridColumn116.FieldName = "CARAT";
            this.gridColumn116.MinWidth = 25;
            this.gridColumn116.Name = "gridColumn116";
            this.gridColumn116.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn116.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum)});
            this.gridColumn116.Visible = true;
            this.gridColumn116.VisibleIndex = 5;
            this.gridColumn116.Width = 94;
            // 
            // gridColumn127
            // 
            this.gridColumn127.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn127.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn127.Caption = "Rate";
            this.gridColumn127.FieldName = "RATE";
            this.gridColumn127.Name = "gridColumn127";
            this.gridColumn127.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn127.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom)});
            this.gridColumn127.Visible = true;
            this.gridColumn127.VisibleIndex = 6;
            // 
            // gridColumn117
            // 
            this.gridColumn117.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn117.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn117.Caption = "Gross Amt";
            this.gridColumn117.FieldName = "GROSSAMOUNT";
            this.gridColumn117.MinWidth = 25;
            this.gridColumn117.Name = "gridColumn117";
            this.gridColumn117.OptionsColumn.AllowEdit = false;
            this.gridColumn117.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn117.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "AMOUNT", "{0:0.##}")});
            this.gridColumn117.Visible = true;
            this.gridColumn117.VisibleIndex = 7;
            this.gridColumn117.Width = 94;
            // 
            // gridColumn118
            // 
            this.gridColumn118.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn118.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn118.Caption = "BROKER_ID";
            this.gridColumn118.FieldName = "BROKER_ID";
            this.gridColumn118.MinWidth = 25;
            this.gridColumn118.Name = "gridColumn118";
            this.gridColumn118.OptionsColumn.AllowEdit = false;
            this.gridColumn118.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn118.Width = 94;
            // 
            // gridColumn119
            // 
            this.gridColumn119.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn119.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn119.Caption = "Entry Date";
            this.gridColumn119.DisplayFormat.FormatString = "dd/MM/yyyy hh:mm:ss tt";
            this.gridColumn119.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn119.FieldName = "ENTRYDATE";
            this.gridColumn119.MinWidth = 25;
            this.gridColumn119.Name = "gridColumn119";
            this.gridColumn119.OptionsColumn.AllowEdit = false;
            this.gridColumn119.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn119.Visible = true;
            this.gridColumn119.VisibleIndex = 10;
            this.gridColumn119.Width = 220;
            // 
            // gridColumn120
            // 
            this.gridColumn120.Caption = "Delete";
            this.gridColumn120.ColumnEdit = this.repositoryItemButtonEdit1;
            this.gridColumn120.FieldName = "DELETE";
            this.gridColumn120.MinWidth = 25;
            this.gridColumn120.Name = "gridColumn120";
            this.gridColumn120.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn120.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.gridColumn120.Width = 94;
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AutoHeight = false;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete)});
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            this.repositoryItemButtonEdit1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // gridColumn121
            // 
            this.gridColumn121.Caption = "Update";
            this.gridColumn121.ColumnEdit = this.repositoryItemButtonEdit2;
            this.gridColumn121.FieldName = "UPDATE";
            this.gridColumn121.MinWidth = 25;
            this.gridColumn121.Name = "gridColumn121";
            this.gridColumn121.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn121.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.gridColumn121.Width = 94;
            // 
            // repositoryItemButtonEdit2
            // 
            this.repositoryItemButtonEdit2.AutoHeight = false;
            this.repositoryItemButtonEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.OK)});
            this.repositoryItemButtonEdit2.Name = "repositoryItemButtonEdit2";
            this.repositoryItemButtonEdit2.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // gridColumn122
            // 
            this.gridColumn122.Caption = "Broker Name";
            this.gridColumn122.FieldName = "BROKERNAME";
            this.gridColumn122.Name = "gridColumn122";
            this.gridColumn122.OptionsColumn.AllowEdit = false;
            this.gridColumn122.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn122.Visible = true;
            this.gridColumn122.VisibleIndex = 11;
            this.gridColumn122.Width = 110;
            // 
            // gridColumn123
            // 
            this.gridColumn123.Caption = "Brok %";
            this.gridColumn123.FieldName = "BROKRAGEPER";
            this.gridColumn123.Name = "gridColumn123";
            this.gridColumn123.OptionsColumn.AllowEdit = false;
            this.gridColumn123.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn123.Visible = true;
            this.gridColumn123.VisibleIndex = 12;
            // 
            // gridColumn124
            // 
            this.gridColumn124.Caption = "Brok Amt";
            this.gridColumn124.FieldName = "BROKRAGEAMOUNT";
            this.gridColumn124.Name = "gridColumn124";
            this.gridColumn124.OptionsColumn.AllowEdit = false;
            this.gridColumn124.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn124.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum)});
            this.gridColumn124.Visible = true;
            this.gridColumn124.VisibleIndex = 13;
            // 
            // gridColumn125
            // 
            this.gridColumn125.Caption = "Remark";
            this.gridColumn125.FieldName = "REMARK";
            this.gridColumn125.Name = "gridColumn125";
            this.gridColumn125.OptionsColumn.AllowEdit = false;
            this.gridColumn125.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn125.Visible = true;
            this.gridColumn125.VisibleIndex = 14;
            // 
            // gridColumn126
            // 
            this.gridColumn126.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn126.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn126.Caption = "Gross Amount(₹)";
            this.gridColumn126.FieldName = "GROSSAMOUNTRS";
            this.gridColumn126.Name = "gridColumn126";
            this.gridColumn126.OptionsColumn.AllowEdit = false;
            this.gridColumn126.OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
            this.gridColumn126.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum)});
            this.gridColumn126.Visible = true;
            this.gridColumn126.VisibleIndex = 8;
            this.gridColumn126.Width = 119;
            // 
            // gridColumn145
            // 
            this.gridColumn145.Caption = "Exc Rate";
            this.gridColumn145.FieldName = "EXCRATE";
            this.gridColumn145.Name = "gridColumn145";
            this.gridColumn145.Visible = true;
            this.gridColumn145.VisibleIndex = 15;
            // 
            // gridColumn146
            // 
            this.gridColumn146.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn146.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn146.Caption = "NetAmt($)";
            this.gridColumn146.FieldName = "NETAMOUNT";
            this.gridColumn146.Name = "gridColumn146";
            this.gridColumn146.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum)});
            this.gridColumn146.Visible = true;
            this.gridColumn146.VisibleIndex = 9;
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // FrmRoughPurchaseView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1216, 639);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Name = "FrmRoughPurchaseView";
            this.Tag = "RoughPurchaseView";
            this.Text = "ROUGH PURCHASE VIEW";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmPurchaseLiveStock_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.BtnCreateKapan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnRejectionTransfer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIsComplete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnUpdate)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GrpCaption)).EndInit();
            this.GrpCaption.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPageRejection.ResumeLayout(false);
            this.xtraTabPageRejection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridRejection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDetRejection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRejectionName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnRejectionDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnRejectionUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).EndInit();
            this.xtraTabPageMixSplit.ResumeLayout(false);
            this.xtraTabPageMixSplit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridMixSplit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDetMixSplit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMixSplitDelete)).EndInit();
            this.xtraTabPageKapan.ResumeLayout(false);
            this.xtraTabPageKapan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridKapan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDetKapan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnKapanDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnKapanUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CmbKapanStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnKapanValuation)).EndInit();
            this.xtraTabPageSale.ResumeLayout(false);
            this.xtraTabPageSale.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridSale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdDetSale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxonContLib.cPanel panel4;
        private AxonContLib.cPanel panel2;
        private DevExpress.XtraGrid.GridControl MainGrid;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit BtnCreateKapan;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit BtnRejectionTransfer;
        private DevExpress.XtraEditors.SimpleButton BtnPrint;
        private DevExpress.XtraEditors.SimpleButton BtnSearch;
        private DevExpress.XtraEditors.SimpleButton BtnAutoFit;
        private DevExpress.XtraEditors.SimpleButton BtnExit;
        private DevExpress.XtraEditors.SimpleButton BtnPCNKapanCreate;
        private AxonContLib.cPanel panel8;
        private DevExpress.XtraEditors.SimpleButton BtnREPKapanCreate;
        private DevExpress.XtraGrid.Views.Grid.GridView GrdDet;
        private DevExpress.XtraGrid.Columns.GridColumn bandedGridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn bandedGridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn bandedGridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn bandedGridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn27;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn28;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn29;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn30;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn31;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn32;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn33;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn34;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn35;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn36;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn37;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn38;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn39;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn40;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn41;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn42;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn43;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn44;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn45;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn46;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn47;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn48;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn49;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn50;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn51;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn52;
        private DevExpress.XtraEditors.SimpleButton ParcelMix;
        private DevExpress.XtraEditors.SimpleButton BtnParcelSplit;
        private AxonContLib.cCheckBox ChkDisplayAllLot;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn53;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn54;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn55;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn56;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn57;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn58;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn59;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn60;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageRejection;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageMixSplit;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageKapan;
        private DevExpress.XtraGrid.GridControl MainGridMixSplit;
        private DevExpress.XtraGrid.Views.Grid.GridView GrdDetMixSplit;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn61;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn62;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn63;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn64;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn65;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn66;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn67;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn68;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn69;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn70;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn71;
        private DevExpress.XtraGrid.GridControl MainGridKapan;
        private DevExpress.XtraGrid.Views.Grid.GridView GrdDetKapan;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn72;
        private DevExpress.XtraGrid.GridControl MainGridRejection;
        private DevExpress.XtraGrid.Views.Grid.GridView GrdDetRejection;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn73;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn74;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn75;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn76;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn77;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn78;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn79;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn80;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn81;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn82;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn94;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn95;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn83;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn84;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn85;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn86;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn87;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn88;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn89;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn90;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn91;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn92;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn93;
        private DevExpress.XtraEditors.GroupControl GrpCaption;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn96;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn97;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit BtnMixSplitDelete;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn98;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn101;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit BtnRejectionDelete;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn102;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit BtnRejectionUpdate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn99;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit BtnKapanDelete;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn100;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit BtnKapanUpdate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn103;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox CmbKapanStatus;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn104;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn105;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn106;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn107;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit txtManager;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit txtRejectionName;
        private DevExpress.XtraEditors.SimpleButton BtnSale;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn108;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageSale;
        private DevExpress.XtraGrid.GridControl MainGridSale;
        private DevExpress.XtraGrid.Views.Grid.GridView GrdDetSale;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn109;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn110;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn111;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn112;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn113;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn114;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn115;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn116;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn117;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn118;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn119;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn120;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn121;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn122;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn123;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn124;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn125;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn126;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn127;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn128;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn129;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn130;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn131;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn132;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn133;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn134;
        private AxonContLib.cComboBox CmbRoughType;
        private AxonContLib.cLabel cLabel5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn135;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnKapanValuation;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn136;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn137;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit chkIsComplete;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn138;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit BtnUpdate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn139;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn140;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn141;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn142;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn143;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn144;
        private AxonContLib.cLabel cLabel1;
        private AxonContLib.cTextBox txtKapan;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn145;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn146;
        private AxonContLib.cLabel lblDefaultLayout;
        private AxonContLib.cLabel lblSaveLayout;
        private AxonContLib.cLabel lblRejectionDeleteLayout;
        private AxonContLib.cLabel lblRejectionSaveLayout;
        private AxonContLib.cLabel lblMixSplitDeleteLayout;
        private AxonContLib.cLabel lblMixSplitSaveLayout;
        private AxonContLib.cLabel lblKapanDeleteLayout;
        private AxonContLib.cLabel lblKapanSaveLayout;
        private AxonContLib.cLabel lblSaleEntryDeletLayout;
        private AxonContLib.cLabel lblSaleEntrySaveLayout;


    }
}