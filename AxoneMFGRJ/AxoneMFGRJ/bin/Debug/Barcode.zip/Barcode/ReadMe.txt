FinalBarcode_TSC : Barcode design in Bartender Ultralite Tsc 

FinalBarcode_TSCGalaxy : Barcode design in Bartender Ultralite Tsc 

And 

FinalBarcode_CitiZen : Barcode is Design in BartenderLable (Old Version which setup is Direct .exe file)